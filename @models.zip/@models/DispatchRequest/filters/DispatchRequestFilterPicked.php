<?php 
/**
@Inject(@models/entityv2/EntityRead);
*/

class DispatchRequestFilterPicked{

   
    function RequestFilterPicked(){
    	$this->EntityRead->SetWhere("dispatch_status='pickedup'");
    }

}