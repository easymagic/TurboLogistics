<?php 
/**
@Inject(@models/entityv2/EntityRead);
*/

class DispatchRequestFilterBooked{

   
    function RequestFilterBooked(){
    	$this->EntityRead->SetWhere("dispatch_status='booked'");
    }

}