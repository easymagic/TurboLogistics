<?php 
/**
@Inject(@models/entityv2/EntityRead);
*/

class DispatchRequestFilterCardPayment{

   
    function RequestFilterCardPayment(){
    	$this->EntityRead->SetWhere("payment_type='card'");
    }

}