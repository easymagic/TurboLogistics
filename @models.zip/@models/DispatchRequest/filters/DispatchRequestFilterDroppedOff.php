<?php 
/**
@Inject(@models/entityv2/EntityRead);
*/

class DispatchRequestFilterDroppedOff{

   
    function RequestFilterDroppedOff(){
    	$this->EntityRead->SetWhere("dispatch_status='droppedoff'");
    }

}