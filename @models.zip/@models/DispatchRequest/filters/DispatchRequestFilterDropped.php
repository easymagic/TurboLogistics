<?php 
/**
@Inject(@models/entityv2/EntityRead);
*/

class DispatchRequestFilterDropped{

   
    function RequestFilterDropped(){
    	$this->EntityRead->SetWhere("dispatch_status='dropped'");
    }

}