<?php 
/**
@Inject(@models/entityv2/EntityRead);
*/
class DispatchRequestListRequest{

   

     function ListRequest(){
       // $this->EntityRead->SetWhere("id=$id");
       $this->EntityRead->Read('dispatch_request');
     }


}