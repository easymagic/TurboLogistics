<?php 
/**
@Inject(@models/entityv2/EntityUpdate,
        @models/entityv2/EntityReadOne,
        @models/User/UserGetProfile,
        @models/User/UserGetBusyStatus,
        @models/DispatchLog/DispatchLogRequest,
        @models/DispatchRequest/DispatchRequestGetRequestById);
*/
class DispatchRequestBookRequest{

   

     function BookRequest($id,$dispatcher_id,$dispatcher_parent_id){
       global $data;
       
       // $this->GetDispatcherData($dispatcher_id);

       if ($this->UserGetBusyStatus->GetBusyStatus($dispatcher_id) == 'free'){

       // $this->EntityRead->SetWhere("id=$id");
       // $this->EntityReadOne->ReadOne('dispatch_request');
       $this->DispatchRequestGetRequestById->GetRequestById($id);

       if (in_array($data['dispatch_request_data']['dispatch_status'],array('pending','cancelled','dropped'))){
         $this->EntityRead->SetWhere("id=$id");
         
         $this->EntityUpdate->SetData(array(
          'user_id'=>$dispatcher_id,
          'user_parent_id'=>$dispatcher_parent_id,
          'dispatch_status'=>'booked'
         ));

         $this->EntityUpdate->DoUpdate('dispatch_request');
         $data['message'] = 'Request booked successfully.';
         $data['error'] = false;
         $data['dispatch_request_data']['user_id'] = $dispatcher_id;
         $data['dispatch_request_data']['user_parent_id'] = $dispatcher_parent_id;

         ///update dispatcher to booked
         $this->EntityRead->SetWhere("id=$dispatcher_id");
         $this->EntityUpdate->SetData(array(
           'dispatch_availability'=>'booked'
         ));
         $this->EntityUpdate->DoUpdate('user');

         ///send notification
         $this->SendNotification($data['dispatch_request_data']);

         //Log this request.
         $this->DispatchLogRequest->LogRequest(array(
           'dispatch_id'=>$id,
           'dispatch_status'=>'booked',
           'user_id'=>$dispatcher_id,
           'lat'=>$data['user_data']['lat'],
           'lng'=>$data['user_data']['lng'],
           'address'=>$data['user_data']['current_address']
         ));

       }else{
         $data['message'] = 'This request has already booked by you (' . $data['dispatch_request_data']['dispatch_status'] . ')!';
         $data['error'] = true;
       }

      }else{

         $data['message'] = 'This dispatcher has already been booked by someone else!';
         $data['error'] = true;

      } 

     }

     // private function GetDispatcherData($user_id){
     //   $this->UserGetProfile->GetProfile($user_id);
     // }


     private function SendNotification(){

     }


}