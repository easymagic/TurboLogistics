<?php
/**
@Inject(@models/entityv2/EntityUpdateUpload);
*/

class UserUpdatePassport{
  

   function UpdatePassport($id){
     global $data;

     $this->EntityRead->SetWhere("id=$id");
     $this->EntityUpdateUpload->UpdateUpload('user','passport','uploads/user/passport/');
     
     $data['message'] = 'Passport updated successfully.';
     
   }


}