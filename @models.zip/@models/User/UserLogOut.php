<?php 

class CustomerLogOut{
  

   function LogOut(){
    global $session;
    global $data;

    @unset($session['user_session']);
    $data['message'] = 'You just logged out.';
   }

}