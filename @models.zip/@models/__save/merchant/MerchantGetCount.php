<?php 

/**

@Inject(@models/entityv2/EntityCount);

*/
class MerchantGetCount{

  

  function GetCount(){
     return $this->EntityCount->GetCount('merchant');
  }



}