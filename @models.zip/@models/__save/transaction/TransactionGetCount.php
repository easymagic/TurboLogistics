<?php 
/**

@Inject(@models/entityv2/EntityCount);

*/


class TransactionGetCount{
  


  function GetCount(){
     return $this->EntityCount->GetCount('transaction');
  }



}