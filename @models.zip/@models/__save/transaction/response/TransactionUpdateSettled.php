<?php 
/**

@Inject(@models/entityv2/EntityUpdate);

*/


class TransactionUpdateSettled{
  


  function UpdateSettled($criteria){
  	 $this->EntityUpdate->Update('transaction',array('pstatus'=>'settled'),$criteria);
     // return $this->EntitySum->GetSum('transaction','amount');
  }



}