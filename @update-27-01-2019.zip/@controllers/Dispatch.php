<?php 
/**
@Inject(@plugins/client/ClientFrontEndPlugin);
*/
class Dispatch{

  
   function Init(){
  	InstallPlugin($this->ClientFrontEndPlugin);
  	InstallTheme('@themes/ClientFrontendFramework');
   }

   function Index(){
   	 // print_r($this->GetIPLatLng());
   }
  

   function Request_ClientContent(){}


   function GetPlace($searchText='ajah'){

   	 global $buffer;
   	 global $contentType;
   	 global $data;
   	 global $json;

   	 $location = $this->GetIPLatLng();

   	 $contentType = 'json';

		// if (!isset($_GET['searchText'])){
		//   $_GET['searchText'] = 'ajah';
		// }

		$curl = curl_init();


		$searchText = explode(' ', $searchText);
		$searchText = implode('+', $searchText);

		curl_setopt_array($curl, array(
		  CURLOPT_URL => "https://maps.googleapis.com/maps/api/place/autocomplete/json?key=AIzaSyDgzNrN0i8WNwm3bOiWFeXt_bQFy4Vr5Vs&input=" . $searchText . "&location=" . $location['lat'] . ',' . $location['lng'] . "&radius=50000",
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 30,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "GET",
		  CURLOPT_POSTFIELDS => "",
		  CURLOPT_HTTPHEADER => array(
		    "Postman-Token: 8af565f0-d980-4c00-be48-240f6e3cb92d",
		    "cache-control: no-cache"
		  ),
		));

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);

		if ($err) {
		  $json['message'] = "cURL Error #:" . $err;
		  $json['error'] = true;
		} else {
		  $json = json_decode($response,true);
		  $json_decode['error'] = false;
		  // print_r($data);
		}




   }


   function GetIPLatLng(){
     
     $new_arr[]= unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$_SERVER['REMOTE_ADDR']));
     // echo "Latitude:".$new_arr[0]['geoplugin_latitude']." and Longitude:".$new_arr[0]['geoplugin_longitude'];   	
     return array(
     	'lat'=>$new_arr[0]['geoplugin_latitude'],
     	'lng'=>$new_arr[0]['geoplugin_longitude']
     );

   }





}