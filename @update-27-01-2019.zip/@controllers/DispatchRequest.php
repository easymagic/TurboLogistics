<?php 
/**
@Inject(@plugins/apis/UserPlugin,
        @plugins/authlogged/AdminBackEndPlugin,
        @plugins/ai/BrainChildPlugin,
        @models/entityv2/EntityRead);
*/

class DispatchRequest{
  

  function Init(){  


   global $DispatchRequestPickupRequest_Redirect;	
   global $DispatchRequestConfirmPaymentAsCash_Redirect;
   global $DispatchRequestConfirmPaymentAsPOS_Redirect;
   global $DispatchRequestDropOffRequest_Redirect;
   global $DispatchRequestCancelRequest_Redirect;

    $redirectPoint = 'DispatchRequest/ListRequests';

    $DispatchRequestPickupRequest_Redirect = $redirectPoint;
    $DispatchRequestConfirmPaymentAsCash_Redirect = $redirectPoint;
    $DispatchRequestConfirmPaymentAsPOS_Redirect = $redirectPoint;
    $DispatchRequestDropOffRequest_Redirect = $redirectPoint;
    $DispatchRequestCancelRequest_Redirect = $redirectPoint;
    
    InstallTheme('@themes/AdminBackEndFramework');

    // InstallPlugin($this->UserPlugin);
    InstallPlugin($this->AdminBackEndPlugin);
    InstallPlugin($this->BrainChildPlugin);

    

  }

  function Page_Init(){
  	global $postData;
    $postData['role'] = 'staff'; //set this by default from the server-side for security reasons.
  }

  private function HasValue($r,$key){
   return (isset($r[$key]) && !empty($r[$key]));
  }

  function Filter_DispatchRequest(){
    // echo 'Called.';
    global $get;

    global $role;
    global $parent_id;  

    if (in_array($role, array('staff','company','company-staff','dispatcher'))){
      $this->EntityRead->SetWhere("user_parent_id = '$parent_id'");
    }


    //SELECT * FROM dispatch_request where ((date_created >= '2019-01-24 00:00:00' and date_created <= '2019-01-24 23:59:59'))
    if ($this->HasValue($get,'filter_date_start') && $this->HasValue($get,'filter_date_stop')){
       
       $date_start = $get['filter_date_start'];
       $date_stop = $get['filter_date_stop'];
       $this->EntityRead->SetWhere("(date_created >= '$date_start 00:00:00' and date_created <= '$date_stop 23:59:59')");

    }


    if ($this->HasValue($get,'filter_payment_type')){
      
      $payment_type = $get['filter_payment_type'];

      $this->EntityRead->SetWhere("payment_type = '$payment_type'");
   
    }


    if ($this->HasValue($get,'filter_payment_status')){

      $payment_status = $get['filter_payment_status'];

      $this->EntityRead->SetWhere("payment_status = '$payment_status'");
     
    }


    if ($this->HasValue($get,'filter_dispatch_status')){
    
      $dispatch_status = $get['filter_dispatch_status'];

      $this->EntityRead->SetWhere("dispatch_status = '$dispatch_status'");

     
    }


  }

  function ListRequests(){
    global $db_sql;

    // echo $db_sql;
  }







}
