<?php 
/**
@Inject(@plugins/client/ClientFrontEndPlugin,
        @plugins/client/ClientCustomFrontEndPlugin,
        @models/entityv2/EntityRead);
*/
class Transaction{
  

  function Init(){
  	// global $CustomerLogOut_Redirect;
  	// global $CustomerChangeAccountPassword_Action_Redirect;

  	InstallPlugin($this->ClientFrontEndPlugin);
  	InstallTheme('@themes/ClientFrontendFramework');
  	InstallPlugin($this->ClientCustomFrontEndPlugin);

  	// $CustomerLogOut_Redirect = 'AuthCustomer/LogIn';
  	// $CustomerChangeAccountPassword_Action_Redirect = 'Customer/UpdateAccountProfile';
  }

  
  // function UpdateAccountProfile_CustomClientContent(){}



  function Page_Init(){
  	global $redirect;
  	global $session;
  	global $data;

  	if (!isset($session['customer_session'])){
      $redirect = 'AuthCustomer/LogIn'; 
      $data['error'] = true;
      $data['message'] = 'Session expired, Please login!';
  	}
  }

  
  private function HasValue($r,$key){
   return (isset($r[$key]) && !empty($r[$key]));
  }


  function Filter_DispatchRequest(){
    // echo 'Called.';
    global $get;

    global $role;
    global $parent_id;  
    global $session;

    if (isset($session['customer_session'])){

       $customer_id = $session['customer_session']['id'];

       $this->EntityRead->SetWhere("customer_id = '$customer_id'");

    }

    // if (in_array($role, array('staff','company','company-staff','dispatcher'))){
    //   $this->EntityRead->SetWhere("user_parent_id = '$parent_id'");
    // }


    //SELECT * FROM dispatch_request where ((date_created >= '2019-01-24 00:00:00' and date_created <= '2019-01-24 23:59:59'))
    if ($this->HasValue($get,'filter_date_start') && $this->HasValue($get,'filter_date_stop')){
       
       $date_start = $get['filter_date_start'];
       $date_stop = $get['filter_date_stop'];
       $this->EntityRead->SetWhere("(date_created >= '$date_start 00:00:00' and date_created <= '$date_stop 23:59:59')");

    }


    if ($this->HasValue($get,'filter_payment_type')){
      
      $payment_type = $get['filter_payment_type'];

      $this->EntityRead->SetWhere("payment_type = '$payment_type'");
   
    }


    if ($this->HasValue($get,'filter_payment_status')){

      $payment_status = $get['filter_payment_status'];

      $this->EntityRead->SetWhere("payment_status = '$payment_status'");
     
    }


    if ($this->HasValue($get,'filter_dispatch_status')){
    
      $dispatch_status = $get['filter_dispatch_status'];

      $this->EntityRead->SetWhere("dispatch_status = '$dispatch_status'");

     
    }


  }







}