<?php 
/**
@Inject(@plugins/client/ClientFrontEndPlugin);
*/
class AuthCustomer{

   
    function Init(){
       
      global $AuthCustomerLogIn_Action_Redirect;
      global $AuthCustomerRegister_Action_Redirect;
      global $AuthCustomerChangePasswordReset_Action_Redirect;
      // global $model_Redirect;

      $AuthCustomerLogIn_Action_Redirect = 'Customer/UpdateAccountProfile';
      

      $AuthCustomerRegister_Action_Redirect = 'AuthCustomer/LogIn';
      $AuthCustomerChangePasswordReset_Action_Redirect = 'AuthCustomer/LogIn';

      InstallPlugin($this->ClientFrontEndPlugin);	
      InstallTheme('@themes/ClientFrontendFramework');
    } 

   
   function Index_ClientContent(){
   	global $redirect; 
   	$redirect = 'AuthCustomer/LogIn';
   }

   function LogIn_ClientContent(){}
   function Register_ClientContent(){}
   function ChangePasswordReset_ClientContent(){}
   function SendPasswordReset_ClientContent(){}


   function Page_Init(){
   	global $session;
   	global $redirect;
   	if (isset($session['customer_session'])){
       $redirect = 'Home/Index';
   	}
   }

   function Page_Destroy(){
   }



}