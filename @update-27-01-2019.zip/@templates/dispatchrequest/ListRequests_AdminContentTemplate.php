<?php 
 global $role;
?>
<section class="content-header">
      <h1>
        Transactions
        <!-- <small>Version 2.0</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">List Transactions</li>
      </ol>
</section>

<style type="text/css">
  th{
    text-transform: uppercase;
    background-color: #5d5757;
    color: #fff;
  }


  .pickedup{
    background-color: #e8e82c;
  }

  .droppedoff{
    background-color: #6dea6d;
  }

  .booked{
    background-color: #e4b764;
  }


</style>

<section class="content">
<div class="row">


<div class="col-md-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">List Transactions</h3>
              
              <div>
                
                <div align="right" style="font-size: 22px;">
                 <b>Total :   &#8358;<?php echo number_format($tran_sum); ?></b>
                </div>
                
                <div align="right">
                 <b>Count:   <?php echo number_format($tran_count); ?></b>
                </div>
                
                
              </div>


              <div>
                <form method="get">
                  <input type="" id="date_start" autocomplete="off" name="filter_date_start" placeholder="Date From" />
                  <input type="" id="date_stop" autocomplete="off" name="filter_date_stop" placeholder="Date To" />
                  
                  <select style="padding: 2px;" name="filter_payment_type">
                    <option value="">Type</option>
                    <option value="cash">Cash</option>
                    <option value="card">Card</option>
                    <option value="pos">POS</option>
                  </select>

                  <select style="padding: 2px;" name="filter_payment_status">
                    <option value="">Payment</option>
                    <option value="success">Success</option>
                    <option value="pending">Pending</option>
                  </select>

                  <select style="padding: 2px;" name="filter_dispatch_status">
                    <option value="">Dispatch</option>
                    <option value="booked">Booked</option>
                    <option value="droppedoff">Dropped Off</option>
                    <option value="pickedup">Picked Up</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                  <button type="submit" style="border: 1px solid orange;background-color: #674848;color: #fff;">FILTER</button>


                </form>
              </div>

            </div>
            <!-- /.box-header -->
            <!-- table-striped -->
            <div class="box-body">
              <table class="table" style="font-size: 12px;">
                <tbody>

                <tr>
                  <th style="width: 10px">#</th>
                  <th>Tran-ID</th>
                  <th>Amount</th>
                  <th>Logistics</th>
                  <th>Period</th>
                  <th>Status</th>

                  
                  <th>Date</th>

                  <th>Operations</th>

                </tr>

                <?php 
                  // foreach ($admin_data as $k=>$v){
                while (Iterate('dispatch_request_data')){
                ?>

                <tr class="<?php echo GetRow('dispatch_status'); ?>">
                  <td><?php echo GetRowCount(); ?></td>
                  <td><?php echo GetRow('transaction_id'); ?></td>
                  <td>&#8358;<?php echo number_format(GetRow('dispatch_amount')); ?></td>

                  <!-- logistics start -->
                  <td>
                    <div>
                      <b><u>Pickup: </u></b><?php echo GetRow('pickup_address'); ?>
                    </div>
                    <div>
                      <b><u>Dropoff: </u></b><?php echo GetRow('dropoff_address'); ?>
                    </div>                    
                    <div>
                      <b><u>Company: </u></b><?php echo GetRow('company'); ?>
                    </div>                    

                  </td>
                  <!-- logistics stop -->
                  
                  <td><?php echo GetRow('dispatch_period'); ?></td>
                  
                  <!-- status start -->
                  <td style="text-transform: uppercase;">
                   <b><?php echo GetRow('dispatch_status'); ?>/<?php echo GetRow('payment_type'); ?>/<?php echo GetRow('payment_status'); ?></b>
                  </td>
                  <!-- status stop -->

                  
                  <td><?php echo GetRow('date_created'); ?></td>
                  <td>
                    <?php 
                     if (GetRow('dispatch_status') != 'droppedoff'){
                    ?>
                    <select data-actions="actions" class="form-control">
                      <option value="">Apply Actions</option>
                      
                      <?php 
                       if (GetRow('dispatch_status') == 'booked'){
                      ?>
                      <option value="DispatchRequest/PickupRequest/<?php echo GetRow('id'); ?>">Pick Up</option>
                      <?php 
                       }
                      ?>
                      
                      <?php 
                       if (GetRow('dispatch_status') == 'pickedup' && GetRow('payment_status') == 'success'){
                      ?>
                      <option value="DispatchRequest/DropOffRequest/<?php echo GetRow('id'); ?>">Drop Off</option>
                      <?php 
                       }
                      ?>
                      
                      <?php 
                       if (GetRow('payment_status') != 'success' && GetRow('dispatch_status') == 'pickedup' && GetRow('payment_type') == 'cash'){
                      ?>
                      <option value="DispatchRequest/ConfirmPaymentAsCash/<?php echo GetRow('id'); ?>">Paid Cash</option>

                      <option value="DispatchRequest/ConfirmPaymentAsPOS/<?php echo GetRow('id'); ?>">Paid With POS</option>
                      <?php 
                       }
                      ?>

                      <?php 
                       if (GetRow('dispatch_status') == 'booked'){
                      ?>                      
                      <option value="DispatchRequest/CancelRequest/<?php echo GetRow('id'); ?>">Cancel</option>
                      <?php 
                        }
                      ?>

                    </select>
                    <?php 
                     }
                    ?>


                  </td>
                </tr>

                <tr>
                  <td colspan="8" data-slide-toggle>
                    
                    <button type="button" class="pull-right btn btn-sm btn-info" style="font-size: 14px;padding: 1px;line-height: 1px;width: 104px;height: 27px;letter-spacing: 4px;">Detail</button>

                    <div style="display: none;" data-description>
                      <?php echo GetRow('dispatch_description'); ?>
                    </div> 



                  </td>
                </tr>


                <?php 
                 }
                ?>


              </tbody></table>
            </div>
            <!-- /.box-body -->
            
<!--             <div class="box-footer clearfix">
              <ul class="pagination pagination-sm no-margin pull-right">
                <li><a href="#">«</a></li>
                <li><a href="#">1</a></li>
                <li><a href="#">2</a></li>
                <li><a href="#">3</a></li>
                <li><a href="#">»</a></li>
              </ul>
            </div>
 -->
          </div>
          <!-- /.box -->

        </div>

  <!-- /.col -->
</div>
</section>      
<script type="text/javascript">
  (function($){
    $(function(){

      $('[data-actions]').each(function(){
        $(this).on('change',function(){
          // var vl = $(this).data('actions');
          if (confirm('Do you want to confirm "' + $(this).val() + '"')){
           //commit action
           location.href = '<?php echo BASE_URL; ?>' + $(this).val();
           //
          }
        });
      });



      $('[data-slide-toggle]').each(function(){
        var toggle = false; 
        var $btn = $(this).find('button');
        var $description = $(this).find('[data-description]');

        $btn.on('click',function(){
          if (!toggle){
            $description.slideDown();
          }else{
            $description.slideUp();
          }
          toggle = !toggle;
        });


      });



    });
  })(jQuery);
</script>