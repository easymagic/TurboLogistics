<link rel="stylesheet" href="<?php echo BASE_URL; ?>BE2/plugins/daterangepicker/daterangepicker.css">
<link rel="stylesheet" href="<?php echo BASE_URL; ?>BE2/plugins/datepicker/datepicker3.css">
<script src="<?php echo BASE_URL; ?>BE2/plugins/daterangepicker/daterangepicker.js"></script>
<script src="<?php echo BASE_URL; ?>BE2/plugins/datepicker/bootstrap-datepicker.js"></script>
<?php 
 global $role;
?>
<section class="content-header">
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">List Transactions</li>
      </ol>
</section>

<style type="text/css">
  th{
    text-transform: uppercase;
    background-color: #5d5757;
    color: #fff;
  }


  .pickedup{
    background-color: #e8e82c;
  }

  .droppedoff{
    background-color: #6dea6d;
  }

  .booked{
    background-color: #e4b764;
  }


</style>

<div class="col-md-12">
          <div class="box">
            <div class="box-header with-border">
              
              <div>
                
                <div align="right" style="font-size: 22px;">
                 <b>Total :   &#8358;<?php echo number_format($tran_sum); ?></b>
                </div>
                
                <div align="right">
                 <b>Count:   <?php echo number_format($tran_count); ?></b>
                </div>
                
                
              </div>


              <div>
                <form method="get">
                  <input type="" id="date_start" autocomplete="off" name="filter_date_start" placeholder="Date From" />
                  <input type="" id="date_stop" autocomplete="off" name="filter_date_stop" placeholder="Date To" />
                  
                  <select style="padding: 2px;" name="filter_payment_type">
                    <option value="">Type</option>
                    <option value="cash">Cash</option>
                    <option value="card">Card</option>
                    <option value="pos">POS</option>
                  </select>

                  <select style="padding: 2px;" name="filter_payment_status">
                    <option value="">Payment</option>
                    <option value="success">Success</option>
                    <option value="pending">Pending</option>
                  </select>

                  <select style="padding: 2px;" name="filter_dispatch_status">
                    <option value="">Dispatch</option>
                    <option value="booked">Booked</option>
                    <option value="droppedoff">Dropped Off</option>
                    <option value="pickedup">Picked Up</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                  <button type="submit" style="border: 1px solid orange;background-color: #674848;color: #fff;">FILTER</button>


                </form>
              </div>

            </div>
            <!-- /.box-header -->
            <!-- table-striped -->
            <div class="box-body table-responsive">
              <table class="table" style="font-size: 12px;color: #584c4c;margin-top: 7px;">
                <tbody>

                <tr>
                  <th style="width: 10px">#</th>
                  <th>Tran-ID</th>
                  <th>Amount</th>
                  <th>Logistics</th>
                  <th>Period</th>
                  <th>Status</th>

                  
                  <th>Date</th>

                  

                </tr>

                <?php 
                  // foreach ($admin_data as $k=>$v){
                while (Iterate('dispatch_request_data')){
                ?>
<!-- class="<?php //echo GetRow('dispatch_status'); ?>" -->
                <tr>
                  <td><?php echo GetRowCount(); ?></td>
                  <td><?php echo GetRow('transaction_id'); ?></td>
                  <td>&#8358;<?php echo number_format(GetRow('dispatch_amount')); ?></td>

                  <!-- logistics start -->
                  <td>
                    <div>
                      <b><u>Pickup: </u></b><?php echo GetRow('pickup_address'); ?>
                    </div>
                    <div>
                      <b><u>Dropoff: </u></b><?php echo GetRow('dropoff_address'); ?>
                    </div>                    
                    <div>
                      <b><u>Company: </u></b><?php echo GetRow('company'); ?>
                    </div>                    

                  </td>
                  <!-- logistics stop -->
                  
                  <td><?php echo GetRow('dispatch_period'); ?></td>
                  
                  <!-- status start -->
                  <td style="text-transform: uppercase;">
                   <b><?php echo GetRow('dispatch_status'); ?>/<?php echo GetRow('payment_type'); ?>/<?php echo GetRow('payment_status'); ?></b>
                  </td>
                  <!-- status stop -->

                  
                  <td><?php echo GetRow('date_created'); ?></td>
                </tr>

                <tr>
                  <td colspan="7" data-slide-toggle>
                    
                    <button type="button" class="pull-right btn btn-sm btn-info" style="font-size: 14px;padding: 1px;line-height: 1px;width: 104px;height: 27px;letter-spacing: 4px;">Detail</button>

                    <div style="display: none;" data-description>
                      <?php echo GetRow('dispatch_description'); ?>
                    </div> 



                  </td>
                </tr>

                <?php 
                 }
                ?>


              </tbody></table>
            </div>
            <!-- /.box-body -->
            
<!--             <div class="box-footer clearfix">
              <ul class="pagination pagination-sm no-margin pull-right">
                <li><a href="#">«</a></li>
                <li><a href="#">1</a></li>
                <li><a href="#">2</a></li>
                <li><a href="#">3</a></li>
                <li><a href="#">»</a></li>
              </ul>
            </div>
 -->
          </div>
          <!-- /.box -->

        </div>

  <!-- /.col -->

<script type="text/javascript">
  (function($){
    $(function(){
    
      // $('[data-actions]').each(function(){
      //   $(this).on('change',function(){
      //     // var vl = $(this).data('actions');
      //     if (confirm('Do you want to confirm "' + $(this).val() + '"')){
      //      //commit action
      //      location.href = '<?php //echo BASE_URL; ?>' + $(this).val();
      //      //
      //     }
      //   });
      // });

      $('[data-slide-toggle]').each(function(){
        var toggle = false; 
        var $btn = $(this).find('button');
        var $description = $(this).find('[data-description]');

        $btn.on('click',function(){
          if (!toggle){
            $description.slideDown();
          }else{
            $description.slideUp();
          }
          toggle = !toggle;
        });


      });
   


    });
  })(jQuery);
</script>


<script>
    $(function () {


        $('#date_start').datepicker();
        $('#date_stop').datepicker();

        var date_start = '';
        var date_stop = '';

        $("#date_stop").datepicker( "option", "dateFormat", 'yy-mm-dd');
        $("#date_start").datepicker( "option", "dateFormat", 'yy-mm-dd');


        $('#date_start').val(date_start);
        $('#date_stop').val(date_stop);



        //iCheck for checkbox and radio inputs
        $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
            checkboxClass: 'icheckbox_minimal-blue',
            radioClass: 'iradio_minimal-blue'
        });
        //Red color scheme for iCheck
        $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
            checkboxClass: 'icheckbox_minimal-red',
            radioClass: 'iradio_minimal-red'
        });
        //Flat red color scheme for iCheck
        $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
            checkboxClass: 'icheckbox_flat-green',
            radioClass: 'iradio_flat-green'
        });

        //Colorpicker
        $(".my-colorpicker1").colorpicker();
        //color picker with addon
        $(".my-colorpicker2").colorpicker();

        //Timepicker
        $(".timepicker").timepicker({
            showInputs: false
        });

        //bootstrap WYSIHTML5 - text editor
        $(".textarea").wysihtml5();
    });








</script>