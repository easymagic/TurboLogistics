          <h3>Change Account Password</h3>
          <hr>
          <!-- <p>Please enter your tracking ID below.</p> -->
          <p id="feedback"></p>
          

          <form role="form" id="contact-form" name="contact-form" method="post" action="" class="contact-form">
            

            <div class="form-group">
              <label class="sr-only" for="exampleInputEmail1">Password:</label>
              <input type="password" class="form-control" id="subject" name="password1" placeholder="Password" />
            </div>


            <div class="form-group">
              <label class="sr-only" for="exampleInputEmail1">Confirm Password:</label>
              <input type="password" class="form-control" id="subject" name="password2" placeholder="Password" />
            </div>

            
            <input id="submit-button" type="submit" class="btn btn-sm btn-info" value="Change Password" style="font-size: 15px;">


          </form>
