<td>
  <?php echo $data['email']; ?>
</td>
<td>
  <?php echo $Entity->EntityCheckBox($data['status']); ?>
</td>