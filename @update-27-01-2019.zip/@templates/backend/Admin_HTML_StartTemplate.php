<?php 
 $PATH = BASE_URL . 'BE2/';
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- <title>FordePro | Admin </title> -->
    <title>Turbo - Errands | Admin</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link href="<?php echo $PATH; ?>css/themes/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo $PATH; ?>font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="<?php echo $PATH; ?>bootstrap/css/ionicons.min.css">
    <link rel="stylesheet" href="<?php echo $PATH; ?>plugins/daterangepicker/daterangepicker.css">
    <link rel="stylesheet" href="<?php echo $PATH; ?>plugins/datepicker/datepicker3.css">
    <link rel="stylesheet" href="<?php echo $PATH; ?>plugins/iCheck/all.css">
    <link rel="stylesheet" href="<?php echo $PATH; ?>lugins/colorpicker/bootstrap-colorpicker.min.css">
    <link rel="stylesheet" href="<?php echo $PATH; ?>plugins/timepicker/bootstrap-timepicker.min.css">
    <link rel="stylesheet" href="<?php echo $PATH; ?>plugins/select2/select2.min.css">
    <link rel="stylesheet" href="<?php echo $PATH; ?>dist/css/AdminLTE.min.css">
    <link rel="stylesheet" href="<?php echo $PATH; ?>dist/css/skins/_all-skins.min.css">
    <link rel="stylesheet" href="<?php echo $PATH; ?>plugins/jvectormap/jquery-jvectormap-1.2.2.css">
    <link rel="stylesheet" href="<?php echo $PATH; ?>dist/css/AdminLTE.min.css">
    <link rel="stylesheet" href="<?php echo $PATH; ?>dist/css/skins/_all-skins.min.css">
    <link rel="stylesheet" href="<?php echo $PATH; ?>plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
    
<!--     <link rel="shortcut icon" type="image/png" href="<?php //echo $PATH; ?>images/Fordepro_favicon.png"/>
 -->
<link rel="shortcut icon" href="https://turboerrands.com/favicon.ico" type="image/x-icon">
<link rel="icon" href="https://turboerrands.com/favicon.ico" type="image/x-icon">

<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDgzNrN0i8WNwm3bOiWFeXt_bQFy4Vr5Vs&libraries=geometry"></script>
<!-- custom map -->
<script type="text/javascript" src="<?php echo BASE_URL; ?>FE2/js/map.js"></script>

<script src="<?php echo $PATH; ?>plugins/jQuery/jquery-2.2.3.min.js"></script>


    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="http://localhost/admin/plugins/jQuery/html5shiv.min.js"></script>
    <script src="http://localhost/admin/plugins/jQuery/respond.min.js"></script>
    <![endif]-->
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
