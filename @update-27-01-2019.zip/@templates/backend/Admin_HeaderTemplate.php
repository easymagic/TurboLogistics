<?php 
global $role;
global $userID;
?>    
    <header class="main-header">
        <a href="" class="logo" style="background-color: #fff;">
            <span class="logo-mini"><img src="https://turboerrands.com/FE2/images/logo.fw.png" style="height: 45px"></span>
            <span class="logo-lg"><img src="https://turboerrands.com/FE2/images/logo.fw.png" style="height: 45px"></span>
        </a>

        <nav class="navbar navbar-static-top">
            <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
                <span class="sr-only">Toggle navigation</span>
            </a>
            <div class="navbar-custom-menu">
                <ul class="nav navbar-nav">

                    <!-- Notifications: style can be found in dropdown.less -->


                    <li class="dropdown user user-menu">
<?php 
 $label = ucfirst($role) . ' , <span style="color:#bce2bc;">' . $userID . '</span>';
?>                        
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <span class="hidden-xs"><?php echo $label; ?></span>
                        </a>
                        <ul class="dropdown-menu">
                            <!-- Menu Footer-->
                            <li class="user-footer">

                                <div class="pull-left">
                                <a href="<?php echo BASE_URL; ?>User/ChangeAccountPassword"
                                       class="btn btn-default btn-flat">Change Password</a>
                                </div>

                                <div class="pull-right">
                                    <a href="<?php echo BASE_URL; ?>User/LogOut" class="btn btn-default btn-flat">Sign
                                        out</a>
                                </div>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>

        </nav>
    </header>
