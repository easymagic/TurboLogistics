<?php 
global $FE_PATH; 
?>
<section class="slider">
  <div id="myCarousel" class="carousel slide carousel-fade" data-ride="carousel">
    <div class="carousel-inner">
      <div class="item"> <img data-src="<?php echo $FE_PATH; ?>images/slider/image_1920x750.fw.png" alt="First slide" src="<?php echo $FE_PATH; ?>images/slider/image_1920x750.fw.png">
        <div class="container">
          <div class="carousel-caption">
            <p></p>
            <h1>We Deliver Fast</h1>
            <p><a class="btn btn-default btn-lg" href="" role="button">try us now</a><a class="btn btn-default btn-lg" href="" role="button">Services</a></p>
          </div>
        </div>
      </div>
      <div class="item active"> <img data-src="<?php echo $FE_PATH; ?>images/slider/image_1920x750.2.fw.png" alt="Second slide" src="<?php echo $FE_PATH; ?>images/slider/image_1920x750.2.fw.png">
        <div class="container">
          <div class="carousel-caption">
            <p></p>
            <h1>We'll Deliver.</h1>
            <p><a class="btn btn-default btn-lg" href="" role="button">try us now</a><a class="btn btn-default btn-lg" href="" role="button">Services</a></p>
          </div>
        </div>
      </div>
    </div>
    <a class="left carousel-control" href="#myCarousel" data-slide="prev"><span class="glyphicon carousel-control-left"></span></a> <a class="right carousel-control" href="#myCarousel" data-slide="next"><span class="glyphicon carousel-control-right"></span></a> </div>
</section>
<!--end of slider section-->




<section class="main__middle__container">
  <div class="row text-center no-margin nothing">
    <div class="container headings">
      <h1 class="page_title">WE <span>DELIVER</span> FAST. </h1>
    <p><a class="btn btn-info btn-lg" href="" role="button">TRY US <img src="<?php echo $FE_PATH; ?>images/slider/icon.fw.png" width="42" height="39"></a></div>
  </div>


<section class="main__middle__container">
  <div class="container">
    <div id="portfolio" class="row no_padding title__block nothing no-margin">
      <ul class="list-unstyled controls">
        <li class="filter" data-filter="all">All Services</li>
        <li class="filter" data-filter="webdesign">Dedicated Delivery Services</li>
        <li class="filter" data-filter="printing">Door to Door Delivery Services</li>
        <li class="filter" data-filter="development">Delivery Fleet Management</li>
        <li class="filter" data-filter="seo">Bulk Mail Delivery</li>
        <li class="filter" data-filter="cash">Cash on Delivery</li>
      </ul>
          <ul id="Grid" class="gallery">
        <li class="mix webdesign col-sm-4"> <a href="<?php echo $FE_PATH; ?>images/gallery/dedicated.png"><img alt="" src="<?php echo $FE_PATH; ?>images/gallery/dedicated.png" class="img-responsive"> <span class="text">Need a dedicated bike?<span></span></span></a> <p><br><h4><b>Need a dedicated bike? </b></h4> We will have a bike and driver dedicated to ensuring your delivery needs are met.<br /><br /></p></li>

        <li class="mix printing col-sm-4"> <a href="<?php echo $FE_PATH; ?>images/gallery/expressdelivery.fw.png"><img alt="" src="<?php echo $FE_PATH; ?>images/gallery/expressdelivery.fw.png" class="img-responsive"> <span class="text">Express deliveries (same day service)<span></span></span></a><p><br><h4><b>Express deliveries (same day service)</b></h4>To have your items delivered same day, contact us between 9am to 5pm Mondays to Saturday to schedule item pickup.<br /><br /></p>
</li>
        <li class="mix printing col-sm-4"> <a href="<?php echo $FE_PATH; ?>images/gallery/regular.png"><img alt="" src="<?php echo $FE_PATH; ?>images/gallery/regular.png" class="img-responsive"> <span class="text">Regular deliveries (next day service)<span></span></span></a><p><br><h4><b>Regular deliveries (next day service)</b></h4>To have your items delivered next day, contact us between 9am to 5pm Mondays to Saturday to schedule item pickup. <br /><br /></p></li>

        <li class="mix development col-sm-4"> <a href="<?php echo $FE_PATH; ?>images/gallery/ownbike.png"><img alt="" src="<?php echo $FE_PATH; ?>images/gallery/ownbike.png" class="img-responsive"> <span class="text">Own your own delivery bikes?<span></span></span></a> <p><br><h4><b>Own your own delivery bikes?</b></h4>We've got you covered. Lets manage your bikes and profit marginis. Bike maintainace also covered in the service. <br> *Terms and conditions apply. <br /><br /></p></li>
        
        <li class="mix seo col-sm-4"> <a href="<?php echo $FE_PATH; ?>images/gallery/bulkdelivery.png"><img alt="" src="<?php echo $FE_PATH; ?>images/gallery/bulkdelivery.png" class="img-responsive"> <span class="text">Have bulk mail to deliver?<span></span></span></a> <p><br><h4><b>Have bulk mail to deliver?</b></h4>We will deliver your bulk mail such as wedding invitations, concert tickets, ceremony invitations, aso-ebi, etc to your guests within Lagos. Arrangements can be made to cover other local or international cities. <br /><br /></p></li>

        <li class="mix cash col-sm-4"> <a href="<?php echo $FE_PATH; ?>images/gallery/cashondelivery.png"><img alt="" src="<?php echo $FE_PATH; ?>images/gallery/cashondelivery.png" class="img-responsive"> <span class="text">Need us to take cash on Delivery?<span></span></span></a> <p><br><h4><b>Need us to take cash on Delivery?</b></h4>We accept cash on delivery on your behalf from your customers and remit to your bank account. We remit cash every Monday. Transaction charges for cash handling and remittance are 1.5% for cash above 10,000 Naira and 200 for cash below 10 ,000 Naira. <br /><br /></p></li>
                
      </ul>
    </div>
    <h2>VALUE PROPOSITION</h2>
    <hr>
    <div class="one_third">
      <h4>Money Back Guarantee</h4>
      <br>
	<p>If we don't deliver as agreed, we'll make a refund. <br>
Terms and conditions apply.</p>
    </div>
    <div class="one_third">
      <h4>We deliver</h4>
      <br>
	<p>We'll deliver. No stories.</p>
    </div>
    <div class="one_third column-last">
      <h4>We deliver fast</h4>
      <br>
	<p>We say we'll deliver fast, so we do.</p>
    </div>
    <div class="dc_clear"></div>
    <br />
    <br />
    <br />
  </div>
</section>
  
  
  <div class="row no-margin grey-info-block text-center">
    <div class="container">
      <div class="col-md-6">
        <h3>24/7 delivery</h3>
        <p class="small-paragraph light">For dedicated customers only.</p>
        <img src="<?php echo $FE_PATH; ?>images/content__images/24.7.fw.png" alt="pic" class="img-rounded img-responsive">
        <p>Our bikes and bikers will become part of your team. They'll deliver all day, everyday.</p>
        <p><a href="" class="btn btn-default btn-lg">Try us <img src="<?php echo $FE_PATH; ?>images/slider/icon.fw.png" width="42" height="39"></a></p>
      </div>
      <div class="col-md-6">
        <h3>8/7 Delivery</h3>
        <p class="small-paragraph light">For dedicated customers only.</p>
        <img src="<?php echo $FE_PATH; ?>images/content__images/8.7.fw.png" alt="pic" class="img-rounded img-responsive">
        <p>Our bikes and bikers work 8 hours daily while seconded to your company. </p>
        <p><a href="" class="btn btn-default btn-lg">Try us <img src="<?php echo $FE_PATH; ?>images/slider/icon.fw.png" width="42" height="39"></a></p>
      </div>
    </div>
  </div>

  <div class="row text-center no-margin nothing red__line testimonials">
    <div class="container headings">
      <h2 class="page_title">TESTIMONIALS</h2>
      <span class="sep"></span>
      <p class="small-paragrapher"><small>What our clients say.</small></p>
      <div id="myCarousel2" class="carousel slide carousel-fade" data-ride="carousel">
        <ol class="carousel-indicators">
          <li data-target="#myCarousel2" data-slide-to="0" class="active"></li>
          <li data-target="#myCarousel2" data-slide-to="1"></li>
          <li data-target="#myCarousel2" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
          <div class="item active">
            <p class="small-paragraph">"Quisque tristique sem ut lacus pulvinar sodales. Praesent ultricies sed suscipit tincidunt. Pellentesque eros dui, interdum vel elit vel. Nunc semper mauris sed eros accumsan, quis viverra. Cras sed leo non sem dictum."</p>
            <p class="small-paragraph"><small>John Smith, Developer</small></p>
          </div>
          <div class="item">
            <p class="small-paragraph">"Donec non faucibus quam. Proin sagittis lectus vitae dapibus pellentesque. Morbi at magna pellentesque, vulputate nisl nec. Donec non faucibus quam. Integer non venenatis nunc."</p>
            <p class="small-paragraph"><small>Daniel Stone, Manager</small></p>
          </div>
          <div class="item">
            <p class="small-paragraph">"Cras sed leo non sem dictum vulputate nec a nisi. Aliquam erat volutpat. Vivamus facilisis purus eu cursus dictum. Aliquam rutrum est sed purus elementum. Nunc condimentum est in nisi dictum."</p>
            <p class="small-paragraph"><small>Alison Parks, Sales</small></p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>