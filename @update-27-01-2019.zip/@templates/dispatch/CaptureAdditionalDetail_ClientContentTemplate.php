<?php 
 global $charging_flat_rate;
 global $payStackEcho;
 global $paymentTypeResponse;
?> 
<section class="main__middle__container">
  
<!--   <div class="row no_padding no-margin nothing nice__title2 blog text-center">
    <div class="container">
      <h2>Customer</h2>
      <span class="sep"></span>
      <p><font color="#000000">Register</font></p>
    </div>
  </div>
 -->

  <section class="recent-posts">
    <div class="container" style="
    width: 100%;
    padding: 0;
">

      <div class="row" style="padding-top: 0;padding: 0;margin: 0;/* width: 100%; */">
        <div class="col-xs-12" style="
    padding: 0;
"> 


   <div id="dvMap" style="height: 500px;">
   </div>

<!-- style="width: 100%; height: 500px;" -->
         
     <!-- [start] -->


<style type="text/css">
  .predictions-list-item:hover{
    background-color: #329832;
    color: #fff;
  }  


  @media(max-width: 768px){

     .handle-mobile{
      width: 100% !important;
      margin: 0 !important;
      padding: 5px !important;
     }

     .pull-right{
      float: right !important;
     }

     .mob-underline{
      text-decoration: underline !important;
     }

     .mob-request-btn{
      background-color: #ddd;
     }

  }
</style>


<!-- rgba(0,0,0,0.2) -->
<div class="handle-mobile" style="position: absolute;top: 4%;margin-left: 10%;background-color: rgba(255,255,255,0.5);padding: 11px;width: 80%;overflow-y: scroll;height: 466px;">

<?php 
 if (!isset($paymentTypeResponse)){
?>


<h2 style="margin-top: 0;" align="center">
  CAPTURE ADDITIONAL DETAIL AND CHECKOUT
</h2>

   
 <!-- dispatchers list -->
 <div class="col-xs-12">

 <div class="col-xs-12" style="background-color: #111;padding: 4px;color: #fff;">
   <b  class="col-xs-12 col-md-5">
     From Pickup : <?php echo $pickup_address; ?>&nbsp;
   </b>

   <b class="pull-right col-xs-12 col-md-5" >
     To DropOff : <?php echo $dropoff_address; ?>&nbsp;
   </b>

 </div>

 <form method="post">
 <div class="col-xs-12" style="background-color: #fff;padding-top: 13px;padding-bottom: 13px;">
     

     <?php 
       // print_r($dispatch_request_data);
       //4
     ?>

     <div class="col-xs-12">
       <p>Marked fiels (*) are compulsory</p>
     </div>

     <div class="form-group">
       <textarea required="" name="data[dispatch_description]" class="form-control" placeholder="*Description Of Your Package."><?php echo $dispatch_request_data['dispatch_description']; ?></textarea>
     </div>

     <div class="form-group">
       <input type="text" required="" placeholder="*Phone" name="data[requester_phone]" class="form-control" value="<?php echo $dispatch_request_data['requester_phone']; ?>" />
     </div>

     <div class="form-group">
      <select required="" name="data[dispatch_period]" class="form-control" id="dispatch_period">
        <option value="now">--Select Period (Defaults To Now)--</option>
        <option value="now">Deliver On this day</option>
        <option value="later">Deliver at a later day</option>
      </select>
     </div>

     <span id="dispatch_period_container" style="display: none;">
     <div class="form-group">
       <label>
         Select Date To Dispatch
       </label>
     </div>

     <div class="form-group">
       <input type="date" name="data[dispatch_period_date]" class="form-control" placeholder="Date To Deliver" value="<?php echo $dispatch_request_data['dispatch_period_date']; ?>" />
     </div>
     </span>

     <div class="form-group">
       <select required="" name="data[payment_type]" class="form-control" id="payment_type">
         <option value="">--Select Method Of Payment--</option>
         <option value="card">Card</option>
         <option value="cash">Cash</option>
       </select>
     </div>

    
    <div class="form-group">
      <label class="form-control">
        Amount: #<?php echo number_format($dispatch_request_data['dispatch_amount']); ?>
      </label>
    </div>

    <div class="form-group">

      <input type="submit" name="" class="btn btn-default btn-sm pull-right" value="Next" style="color: #000;" />

      <img src="https://pbs.twimg.com/profile_images/810741743436124160/sfGjeR7F_400x400.jpg"  style="width: 32px;margin-right: 11px;margin-top: 4px;" class="pull-right" />
    </div>
  


 </div>
 </form>


 </div>  
<?php 
 }else{

  if ($paymentTypeResponse == 'cash'){

?>


<h2 style="margin-top: 0;" align="center">
  CASH ON DELIVERY
</h2>
   
 <!-- dispatchers list -->
 <div class="col-xs-12">

 <form method="post">
 <div class="col-xs-12" style="background-color: #fff;padding-top: 13px;padding-bottom: 13px;">
<div class="alert alert-info" align="center">
  <b>
  Please make cash payment to the dispatcher that wil arrive at your location either via POS, Bank Transfer to the account-detail (Bank: XXXXXXXXXX, A/C No: XXXXXXXX) or by cash
  </b>
</div>
 </div>
 </form>
<?php 
  }else{
?>
<div class="alert alert-info" align="center">
  <b>
    Calling Payment Gateway....
  </b>
</div>
<?php 
  }
 }
?>



</div>



        

        <!-- [end]   -->
          
        </div>
      </div>
    </div>
  </section>
</section>


<script type="text/javascript">
  
       window.onload = function () {

        EventBus.Notify('InitMap',{
          mapId:"dvMap"
        });

        // EventBus.Notify('AddMarkers',{
        //   markers:markers
        // });

        // EventBus.Notify('DrawPath',{
        //   markers:markers
        // });

        EventBus.Notify('ZoomMap',{
          zoom:10
        });


        // EventBus.Subscribe('MapGetDistance',function(result){
        //   console.log(result);
        // });

        // EventBus.Notify('MapComputeDistance',{
        //   locationA:{
        //     lat:markers[0]['lat'],
        //     lng:markers[0]['lng']
        //   },
        //   locationB:{
        //     lat:markers[1]['lat'],
        //     lng:markers[1]['lng']
        //   }
        // });


        // EventBus.Notify('MapDrawRadiusRange',{
        //   lat:markers[1]['lat'],
        //   lng:markers[1]['lng'],
        //   radius:11
        // });

          var markers_ = <?php echo json_encode($markers); ?>;

          EventBus.Notify('AddMarkers',{
            markers:markers_
          });
          EventBus.Notify('DrawPath',{
            markers:markers_
          });
  
          EventBus.Notify('ZoomArroundMarkers',{});    



        // EventBus.Notify('MapInitInputs',{
        //   pickup:'#pickup',
        //   dropoff:'#dropoff'
        // });


       };

(function($){
 $(function(){
 
  $('#dispatch_period').on('change',function(){
    
    if ($(this).val() == 'later'){
      $('#dispatch_period_container').show();
    }else{
      $('#dispatch_period_container').hide();
    }

  });


  $('#dispatch_period').val('<?php echo $dispatch_request_data['dispatch_period']; ?>');
  $('#payment_type').val('<?php echo $dispatch_request_data['payment_type']; ?>');
 
 });
})(jQuery);
</script>
<?php 
 if (isset($payStackEcho)){
   echo $payStackEcho;

 }
?>
