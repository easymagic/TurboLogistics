<?php 
 global $charging_flat_rate;
 global $payStackEcho;
?> 
<section class="main__middle__container">
  
<!--   <div class="row no_padding no-margin nothing nice__title2 blog text-center">
    <div class="container">
      <h2>Customer</h2>
      <span class="sep"></span>
      <p><font color="#000000">Register</font></p>
    </div>
  </div>
 -->

  <section class="recent-posts">
    <div class="container" style="
    width: 100%;
    padding: 0;
">

      <div class="row" style="padding-top: 0;padding: 0;margin: 0;/* width: 100%; */">
        <div class="col-xs-12" style="
    padding: 0;
"> 


   <div id="dvMap" style="height: 500px;">
   </div>

<!-- style="width: 100%; height: 500px;" -->
         
     <!-- [start] -->


<style type="text/css">
  .predictions-list-item:hover{
    background-color: #329832;
    color: #fff;
  }  


  @media(max-width: 768px){

     .handle-mobile{
      width: 80% !important;
     }

  }
</style>


<!-- rgba(0,0,0,0.2) -->
<div class="handle-mobile" style="position: absolute;top: 4%;margin-left: 10%;background-color: rgba(255,255,255,0.5);padding: 11px;width: 80%;">


<h2 style="margin-top: 0;" align="center">
  CARD PAYMENT RESPONSE
</h2>

   
 <!-- dispatchers list -->
 <div class="col-xs-12">
 

  <div class="col-xs-12">
    <?php 
      if (isset($message)){

        ?>

        <div class="alert alert-info" align="center"><b><?php echo $message; ?></b></div>

        <?php 

      }
    ?>
  </div>


 </div>  




</div>



        

        <!-- [end]   -->
          
        </div>
      </div>
    </div>
  </section>
</section>


