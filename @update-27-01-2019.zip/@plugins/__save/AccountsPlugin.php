<?php 

/**

@Inject(@models/admin/AdminLogin,
        @models/merchant/MerchantLogin);

*/


class AccountsPlugin{

  
    function Index_Action(){
      $this->AdminLogin_Action();
    }

    function AdminLogin_Action(){
      $this->AdminLogin->Login();
    }

    function MerchantLogin_Action(){
     $this->MerchantLogin->Login();
    }

    function Page_Destroy(){
      global $session;

      unset($session['data']);
    }



}