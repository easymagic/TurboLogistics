<?php 
/**
@Inject(@templates/frontend/Client_CustomTemplate,
        @templates/frontend/Client_CustomSideBarTemplate);
*/
class ClientCustomFrontEndPlugin{

  
  function Client_Custom(){
    global $buffer;
    global $routeAction;
    global $bufferPatch;
    global $data;
    
    $sideBar = '';

    CallAction('Client_Custom_SideBar');

    $sideBar = $buffer;
    $buffer = '';
    $data['CustomClientSideBar'] = $sideBar;
    
    $content = '';
    CallAction($routeAction . '_CustomClientContent');
    $content = $buffer;
    $data['CustomClientContent'] = $content;

    $buffer = '';
    $buffer.=$this->Client_CustomTemplate->View();
  }

  function Client_Custom_SideBar(){
    global $buffer;
    $buffer.=$this->Client_CustomSideBarTemplate->View();
  }

  ///CustomClientContent


  // function Page_Destroy(){
  //  	global $session;
  //  	global $data;
  //  	if (isset($session['data'])){
  //     unset($session['data']);
  //     $data = array();
  //  	}  	
  // }




}