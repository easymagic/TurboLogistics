<?php 
/**

@Inject(@models/entityv2/EntityAccountCreate,
        @models/admin/AdminGetList,
        @models/entityv2/EntityCheckPassword);

*/

class AdminCreate{

  

  function Create(){
  	global $data;
  	global $postData;
  	global $post;

  	$data['error'] = false;
  	// $this->CheckDuplicateEmail();
  	// $this->EntityCheckPassword->checkPassword();

  	// if (!$data['error']){
  	  // $postData['password'] = $post['password1'];
      $this->EntityCheckPassword->SetData($post);
      $this->EntityAccountCreate->SetDuplicateField('email');
      $this->EntityAccountCreate->SetData($postData);
      $this->EntityAccountCreate->AccountCreate('admin');
  	// }
    
  }

  // private function CheckDuplicateEmail(){
  // 	global $data;
  // 	global $postData;
  // 	global $db_where;

  // 	$db_where = " where (email = '" . $postData['email'] . "')";
  //   $this->AdminGetList->GetList();
  //   if (count($data['admin_data']) > 0){
  //     $data['error'] = true;
  //     $data['message'] = 'An account with this E-mail already exists!';
  //   }


  // }


}