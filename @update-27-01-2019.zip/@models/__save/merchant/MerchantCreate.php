<?php 

/**

@Inject(@models/entityv2/EntityAccountCreate,
        @models/entityv2/EntityGenerateUID,
        @models/merchant/MerchantGetList,
        @models/entityv2/EntityCheckPassword);

*/

class MerchantCreate{


  function Create(){
    global $newID;
    global $data;
    global $postData;
    global $post;

    $data['error'] = false;
    $data['message'] = 'Merchant Account created successfully.';
    // $this->CheckEmailDuplicate();
    // $this->EntityCheckPassword->CheckPassword();
    // if (!$data['error']){
	    $this->EntityAccountCreate->SetData($postData);
      $this->EntityCheckPassword->SetData($post);
      $this->EntityAccountCreate->SetDuplicateField('email');
      $this->EntityAccountCreate->AccountCreate('merchant');
      
      $this->EntityRead->SetWhere("id=$newID");
	    $this->EntityGenerateUID->GenerateUID('merchant','merch_secret',$newID,11);
    // }


  }

  // private function CheckEmailDuplicate(){
  //   global $db_where;
  //   global $postData;
  //   global $data;

  //   $db_where = " where (email = '" . $postData['email'] . "')";
  //   $this->MerchantGetList->GetList();

  //   if (count($data['merchant_data']) > 0){
  //     $data['error'] = true;
  //     $data['message'] = 'An account with this E-mail already exists!';
  //   }

  // }


}