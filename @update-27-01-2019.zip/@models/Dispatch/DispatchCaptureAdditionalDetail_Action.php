<?php 
/**
@Inject(@models/DispatchRequest/DispatchRequestCaptureAdditionalDetail_Action,
        @models/DispatchRequest/DispatchRequestGetOne);
*/
class DispatchCaptureAdditionalDetail_Action{



   function CaptureAdditionalDetail_Action($dispatch_request_id){
   	 global $session;
   	 global $postData;
   	 global $payStackEcho;
   	 global $paymentTypeResponse;
   	 global $data;

   	 $postData['requester_email'] = $session['customer_session']['email'];
     
      $dispatch_request_id = base64_decode($dispatch_request_id);
      // echo 'called.';
      $this->DispatchRequestCaptureAdditionalDetail_Action->CaptureAdditionalDetail_Action($dispatch_request_id);

      if ($postData['payment_type'] == 'card'){
        $this->GetPayStackEcho($dispatch_request_id);
        $paymentTypeResponse = 'card';
      }else{
        $paymentTypeResponse = 'cash';
        $data['message'] = 'Your request has been processed as cash on delivery.';
      }

      

   }

   function GetPayStackEcho($dispatch_request_id){
   	 
   	 global $session;
   	 global $payStackEcho;
   	 global $data;

   	 $this->DispatchRequestGetOne->GetOne($dispatch_request_id);
      
      ob_start();
   	?>
<form>
  <script src="https://js.paystack.co/v1/inline.js"></script>
  <!-- <button type="button" onclick="payWithPaystack()">Pay</button>  -->
</form> 
<script>
  function payWithPaystack(){
    var handler = PaystackPop.setup({
      key:'pk_test_5277568ad00c96f65f9db390d525b05029736023',
      email: '<?php echo $session['customer_session']['email']; ?>',
      amount: <?php echo $data['dispatch_request_data']['dispatch_amount'] * 100; ?>,
      currency: "NGN",
      ref: ''+Math.floor((Math.random() * 1000000000) + 1), // generates a pseudo-unique reference. Please replace with a reference you generated. Or remove the line entirely so our API will generate one for you
      firstname: '<?php echo $session['customer_session']['first_name']; ?>',
      lastname: '<?php echo $session['customer_session']['surname']; ?>',
      // label: "Optional string that replaces customer email"
      metadata: {
         custom_fields: [
            {
                display_name: "Mobile Number",
                variable_name: "mobile_number",
                value: "<?php echo $session['customer_session']['phone']; ?>"
            }
         ]
      },
      callback: function(response){
          // alert('success. transaction ref is ' + response.reference);
          location.href = '<?php echo BASE_URL; ?>Dispatch/CheckCardTransaction/' + response.reference;
          // jQuery.ajax({
          // 	url:',
          // 	type:'get',
          // 	success:function(resp){
          //     console.log(resp);
          // 	}
          // });
      },
      onClose: function(){
          // alert('window closed');
      }
    });
    handler.openIframe();
  }

  payWithPaystack();

</script>
   	<?php
   	$r = ob_get_contents(); 
   	$payStackEcho = $r;
   	ob_end_clean();
   }





}