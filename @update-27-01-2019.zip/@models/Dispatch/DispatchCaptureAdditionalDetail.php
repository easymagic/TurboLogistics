<?php 
/**
@Inject(@models/DispatchRequest/DispatchRequestGetOne,
        @models/SiteSettings/SiteSettingsGetOption);
*/
class DispatchCaptureAdditionalDetail{
  

   function CaptureAdditionalDetail($id){
        global $data;
        global $session;
        global $charging_flat_rate;

        $id = base64_decode($id);

        $session['dispatch_request_id'] = $id;

        $this->DispatchRequestGetOne->GetOne($id);

        $session['user_id'] = $data['dispatch_request_data']['user_id'];

        //save for future login purposes.

    	$data['pickup_address'] = $session['pickup_address'];
    	$data['dropoff_address'] = $session['dropoff_address'];

    	$data['pickup_lat'] = $session['pickup_lat'];
    	$data['pickup_lng'] = $session['pickup_lng'];

    	$data['dropoff_lat'] = $session['dropoff_lat'];
    	$data['dropoff_lng'] = $session['dropoff_lng'];

    	$data['markers'] = array();

    	$data['markers'][] = array(
         'lat'=>$data['pickup_lat'],
         'lng'=>$data['pickup_lng'],
         'description'=>$data['pickup_address']
    	);

    	$data['markers'][] = array(
         'lat'=>$data['dropoff_lat'],
         'lng'=>$data['dropoff_lng'],
         'description'=>$data['dropoff_address']
    	);

    	$data['dispatch_distance'] = $session['dispatch_distance'];

        $charging_flat_rate = $this->SiteSettingsGetOption->GetOption('charging_flat_rate');


   }


}