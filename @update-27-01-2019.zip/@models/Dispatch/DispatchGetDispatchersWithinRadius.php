<?php 
/**
@Inject(@models/User/UserGetDispatchWithinRadius,
        @models/User/UserGetProfile,
        @models/SiteSettings/SiteSettingsGetOption);
*/
class DispatchGetDispatchersWithinRadius{

   
     function GetDispatchersWithinRadius($lat,$lng,$radiusKm){
        global $data;
        global $session;
        global $charging_flat_rate;

        //save for future login purposes.
        $session['intent_action_'] = "Dispatch/GetDispatchersWithinRadius/$lat/$lng/$radiusKm";

    	$data['pickup_address'] = $session['pickup_address'];
    	$data['dropoff_address'] = $session['dropoff_address'];

    	$data['pickup_lat'] = $session['pickup_lat'];
    	$data['pickup_lng'] = $session['pickup_lng'];

    	$data['dropoff_lat'] = $session['dropoff_lat'];
    	$data['dropoff_lng'] = $session['dropoff_lng'];

    	$data['markers'] = array();

    	$data['markers'][] = array(
         'lat'=>$data['pickup_lat'],
         'lng'=>$data['pickup_lng'],
         'description'=>$data['pickup_address']
    	);

    	$data['markers'][] = array(
         'lat'=>$data['dropoff_lat'],
         'lng'=>$data['dropoff_lng'],
         'description'=>$data['dropoff_address']
    	);

    	$data['dispatch_distance'] = $session['dispatch_distance'];

        $charging_flat_rate = $this->SiteSettingsGetOption->GetOption('charging_flat_rate');

        $tmp = array();
        $this->UserGetDispatchWithinRadius->GetDispatchWithinRadius($lat,$lng,$radiusKm);
        $tmp = $data['user_data'];

        foreach ($tmp as $k=>$v){
          $this->UserGetProfile->GetProfile($v['parent_id']);
          $tmp[$k]['company_data'] = $data['user_data'];
        }
        
        $data['user_data'] = $tmp;

     }


}