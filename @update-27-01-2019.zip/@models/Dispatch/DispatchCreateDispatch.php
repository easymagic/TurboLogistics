<?php
/**
@Inject(@models/User/UserGetProfile,
        @models/DispatchRequest/DispatchRequestCreateRequest,
        @models/SiteSettings/SiteSettingsGetOption);
*/
class DispatchCreateDispatch{

  

    function CreateDispatch($dispatcher_id,$company_id){
    	global $session;
    	global $DispatchCreateDispatch_Redirect;
    	global $data;
    	global $dispatch_request_new_id;
    	global $postData;
    	global $charging_flat_rate;

    	$charging_flat_rate = $this->SiteSettingsGetOption->GetOption('charging_flat_rate');

    	$this->UserGetProfile->GetProfile($dispatcher_id);
    	


    	if (isset($session['customer_session'])){

    	  if ($data['user_data']['dispatch_availability'] == 'free'){

    	  	if ($data['user_data']['parent_id'] == $company_id){

		    	$postData['pickup_address'] = $session['pickup_address'];
		    	$postData['dropoff_address'] = $session['dropoff_address'];

		    	$postData['pickup_lat'] = $session['pickup_lat'];
		    	$postData['pickup_lng'] = $session['pickup_lng'];

		    	$postData['dropoff_lat'] = $session['dropoff_lat'];
		    	$postData['dropoff_lng'] = $session['dropoff_lng'];
		    	$postData['customer_id'] = $session['customer_session']['id'];

		    	$postData['user_id'] = $dispatcher_id;
		    	$postData['user_parent_id'] = $company_id;
		    	$postData['dispatch_distance'] = $session['dispatch_distance'];

		    	$this->ComputeRate($company_id);


	              $this->DispatchRequestCreateRequest->CreateRequest($session['customer_session']['id']);

	              $DispatchCreateDispatch_Redirect = 'Dispatch/CaptureAdditionalDetail/' . base64_encode($dispatch_request_new_id);	
		    	  $data['message'] = 'Dispatch request created successfully, complete additional detail provided here.';


    	  	}else{

    	  		$data['message'] = 'Invalid request (url-modified)!';
    	  		// $data['error'] = true;
    	  		//https://turboerrands.com/Dispatch/GetDispatchersWithinRadius/6.4439009/3.475083600000062/15
    	  		$DispatchCreateDispatch_Redirect = 'Dispatch/GetDispatchersWithinRadius/' . $session['pickup_lat'] . '/' . $session['pickup_lng'] . '/' . $session['radius'];

    	  	}




    	  }else{

    	  	$data['message'] = 'This dispatcher has already been booked ahead of you before you completed this request, try booking another dispatcher.';
    	  	$data['error'] = true;

    	  }	

         
    	}else{
           
           $data['message'] = 'Please login to complete your dispatch request.';
           $DispatchCreateDispatch_Redirect = 'AuthCustomer/LogIn';
           $session['intent_action'] = $session['intent_action_'];


    	}
    }


    private function ComputeRate($company_id){
     global $session;
     global $data;
     global $charging_flat_rate;
     global $postData;

     $this->UserGetProfile->GetProfile($company_id); //get company data for rate computation.


     $charging_flat_rate = $this->SiteSettingsGetOption->GetOption('charging_flat_rate');

     $dispatch_distance = $session['dispatch_distance'];
    
     if ($data['user_data']['charging_pattern'] == 'platform'){
        // $postData['']
        $postData['dispatch_amount'] = $charging_flat_rate;
     }else if ($data['user_data']['charging_pattern'] == 'rate-per-km'){
       $postData['dispatch_amount'] = $dispatch_distance * $data['user_data']['charged_rate'];
     }else if ($data['user_data']['charging_pattern'] == 'company-defined-rate'){
       $postData['dispatch_amount'] = $data['user_data']['charged_rate'];
     }else{ //default to platform.
      $postData['dispatch_amount'] = $charging_flat_rate;
     }



    }


}