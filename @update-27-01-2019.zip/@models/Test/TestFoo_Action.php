<?php 

class TestFoo_Action{


   
   function Foo_Action($a=''){
   	global $data;
   	global $post;

   	$data['msg_action'] = 'triggerred action from the @models.' . $post['foo_name'] . ':' . $a;

   }


}