<?php 

class TestFoo{

  
   function Foo(){
   	global $data;
   	$data['msg'] = 'TestFoo initialized ... ';
   	// echo 'Called 2.';
   }


}