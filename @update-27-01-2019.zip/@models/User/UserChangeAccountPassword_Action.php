<?php 
/**
@Inject(@models/User/UserChangePassword_Action);
*/
class UserChangeAccountPassword_Action{


   
   function ChangeAccountPassword_Action(){
   	global $session;
   	$id = $session['user_session']['id'];
    $this->UserChangePassword_Action->ChangePassword_Action($id);
   }

}