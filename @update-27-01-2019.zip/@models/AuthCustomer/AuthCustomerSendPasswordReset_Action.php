<?php 
/**
@Inject(@models/Customer/CustomerSendPasswordReset_Action);
*/
class AuthCustomerSendPasswordReset_Action{
  

   function SendPasswordReset_Action(){
    $this->CustomerSendPasswordReset_Action->SendPasswordReset_Action();
   }


}