<?php 
/**
@Inject(@models/entityv2/EntityCreate);
*/
class DispatchLogRequest{
 


  function LogRequest($data){
    $data['date_created'] = date('Y-m-d h:i:s');
    
    $this->EntityCreate->SetData($data);
    $this->EntityCreate->DoCreate('dispatch_log');

  }


}