<?php 
/**
@Inject(@models/DispatchRequest/DispatchRequestListRequests);
*/
class TransactionListTransactions{

  

    function ListTransactions(){
      $this->DispatchRequestListRequests->ListRequests();
    }


}