<?php 
/**
@Inject(@models/entityv2/EntityUpdate);
*/
class DispatchRequestCaptureAdditionalDetail_Action{
  


     function CaptureAdditionalDetail_Action($id){
        global $postData;
        global $data;

        $this->EntityRead->SetWhere("id=$id");
        $this->EntityUpdate->SetData($postData);
        $this->EntityUpdate->DoUpdate('dispatch_request');

        $data['message'] = 'Additional settings saved.';

     }


}