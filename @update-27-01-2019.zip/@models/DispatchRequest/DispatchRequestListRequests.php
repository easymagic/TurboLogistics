<?php 
/**
@Inject(@models/entityv2/EntityRead,
        @models/User/UserGetProfile,
        @models/DispatchRequest/metrics/DispatchRequestGetCount,
        @models/DispatchRequest/metrics/DispatchRequestGetSum);
*/
class DispatchRequestListRequests{

   

     function ListRequests(){
       // $this->EntityRead->SetWhere("id=$id");
       global $data;
       global $db_sort;

       CallAction('Filter_DispatchRequest');
       $data['tran_sum'] = $this->DispatchRequestGetSum->GetSum();

       CallAction('Filter_DispatchRequest');
       $data['tran_count'] = $this->DispatchRequestGetCount->GetCount();

       CallAction('Filter_DispatchRequest');
       $db_sort = " order by id desc ";
       $this->EntityRead->Read('dispatch_request');

       $tmp = $data['dispatch_request_data'];

       foreach ($tmp as $k=>$v){

       	 $this->UserGetProfile->GetProfile($v['user_parent_id']);

       	 $tmp[$k]['company'] = $data['user_data']['company_name'];

       	 // echo 'sss.';

       }

       $data['dispatch_request_data'] = $tmp;

       // print_r($data['user_data']);


     }


}