<?php 
/**
@Inject(@models/entityv2/EntityCreate,
        @models/entityv2/EntityGenerateUID,
        @models/Customer/CustomerGetProfile,
        @models/DispatchRequest/DispatchRequestBookRequest);
*/
class DispatchRequestCreateRequest{

  


   function CreateRequest($customer_id){
     global $postData;
     global $data;
     global $newID;
     global $dispatch_request_new_id;

     $data['error'] = false;
     
     //perform validations first
     if (!isset($postData['pickup_address']) || empty($postData['pickup_address'])){
       $data['error'] = true;
       $data['message'] = 'Expected pickup address!';
     }
     
     if (!isset($postData['pickup_lat']) || empty($postData['pickup_lat'])){
       $data['error'] = true;
       $data['message'] = 'Expected pickup lat!';
     }

     if (!isset($postData['pickup_lng']) || empty($postData['pickup_lng'])){
       $data['error'] = true;
       $data['message'] = 'Expected pickup lng!';
     }

     if (!isset($postData['dropoff_address']) || empty($postData['dropoff_address'])){
       $data['error'] = true;
       $data['message'] = 'Expected dropoff address!';
     }

     if (!isset($postData['dropoff_lat']) || empty($postData['dropoff_lat'])){
       $data['error'] = true;
       $data['message'] = 'Expected dropoff lat!';
     }

     if (!isset($postData['dropoff_lng']) || empty($postData['dropoff_lng'])){
       $data['error'] = true;
       $data['message'] = 'Expected dropoff lng!';
     }

     // if (!isset($postData['dispatch_description']) || empty($postData['dispatch_description'])){
     //   $data['error'] = true;
     //   $data['message'] = 'Expected dispatch description!';
     // }

     $postData['customer_id'] = $customer_id;


     if (!$data['error']){
       
       $this->CustomerGetProfile->GetProfile($customer_id);	

       $postData['requester_address'] = $data['customer_data']['address'];
       $postData['requester_lat'] = $data['customer_data']['lat'];
       $postData['requester_lng'] = $data['customer_data']['lng'];

       $postData['date_created'] = date('Y-m-d h:i:s');

       $this->EntityCreate->SetData($postData);
       $this->EntityCreate->DoCreate('dispatch_request'); 
       $this->EntityGenerateUID->GenerateUID('dispatch_request','transaction_id',$newID,$len=7);

          // $postData['user_id'] = $dispatcher_id;
          // $postData['user_parent_id'] = $company_id;
       $dispatch_request_new_id = $newID;

       $this->DispatchRequestBookRequest->BookRequest($newID,$postData['user_id'],$postData['user_parent_id']);

       $data['message'] = 'Dispatch request created.';

     }

   }


}