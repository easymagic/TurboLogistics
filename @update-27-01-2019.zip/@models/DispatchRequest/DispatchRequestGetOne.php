<?php 
/**
@Inject(@models/entityv2/EntityReadOne);
*/
class DispatchRequestGetOne{

	function GetOne($id){
      $this->EntityRead->SetWhere("id=$id");
      $this->EntityReadOne->ReadOne('dispatch_request');
	}

}