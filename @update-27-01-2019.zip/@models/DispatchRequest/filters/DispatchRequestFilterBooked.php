<?php 
/**
@Inject(@models/entityv2/EntityRead);
*/

class DispatchRequestFilterBooked{

   
    function FilterBooked(){
    	$this->EntityRead->SetWhere("dispatch_status='booked'");
    }

}