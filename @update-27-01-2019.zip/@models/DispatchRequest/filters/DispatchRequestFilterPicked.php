<?php 
/**
@Inject(@models/entityv2/EntityRead);
*/

class DispatchRequestFilterPicked{

   
    function FilterPicked(){
    	$this->EntityRead->SetWhere("dispatch_status='pickedup'");
    }

}