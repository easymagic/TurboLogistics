<?php 
/**
@Inject(@models/entityv2/EntityRead);
*/

class DispatchRequestFilterCashPayment{

   
    function FilterCashPayment(){
    	$this->EntityRead->SetWhere("payment_type='cash'");
    }

}