<?php 
/**
@Inject(@models/Customer/CustomerGetProfile);
*/
class CustomerUpdateAccountProfile{
  

   function UpdateAccountProfile(){
    global $session;
    $id = $session['customer_session']['id'];
    $this->CustomerGetProfile->GetProfile($id);
   }


}