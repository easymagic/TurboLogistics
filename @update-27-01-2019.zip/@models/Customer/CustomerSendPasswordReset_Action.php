<?php 
/**
@Inject(@models/entityv2/EntitySendPasswordReset);
*/
class CustomerSendPasswordReset_Action{

  

    function SendPasswordReset_Action(){
      $this->EntitySendPasswordReset->SendPasswordReset('customer','AuthCustomer');
    }


}