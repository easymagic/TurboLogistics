<?php 

class CustomerLogOut{
  

   function LogOut(){
    global $session;
    global $data;

    unset($session['customer_session']);
    $data['message'] = 'You just logged out.';
   }

}