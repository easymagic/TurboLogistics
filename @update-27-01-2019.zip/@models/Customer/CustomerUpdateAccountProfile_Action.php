<?php 
/**
@Inject(@models/Customer/CustomerUpdateProfile_Action);
*/
class CustomerUpdateAccountProfile_Action{

  

   function UpdateAccountProfile_Action(){
   	 global $session;
   	 $id = $session['customer_session']['id'];
     $this->CustomerUpdateProfile_Action->UpdateProfile_Action($id);
   }


}