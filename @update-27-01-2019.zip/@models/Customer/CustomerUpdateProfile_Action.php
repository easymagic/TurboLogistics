<?php 
/**
@Inject(@models/entityv2/EntityUpdate);
*/

class CustomerUpdateProfile_Action{

  

   function UpdateProfile_Action($id){
   	 global $postData;
   	 global $data;
     
     //for security reasons.
     unset($postData['email']);
     unset($postData['password']);

     $this->EntityRead->SetWhere("id=$id");
     $this->EntityUpdate->SetData($postData);
     $this->EntityUpdate->DoUpdate('customer');

     $data['message'] = 'Profile Saved.';
   }


}