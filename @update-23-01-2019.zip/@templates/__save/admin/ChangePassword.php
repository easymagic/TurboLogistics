<?php 

// Provide('user.UserRead',array(
//  'where'=>array(
//    'id'=>$id
//  )
// ));

// global $data;


if (count($data) > 0){

  $data = $data[0];

?>
<form method="post">
<div class="row flex-grow">


                <div class="col-12 grid-margin">

<?php 
 // LogvMessage();
?>

                  <div class="card">
                    <div class="card-body">
                      <h4 class="card-title">Change Password</h4>
                      <p class="card-description" align="right">
<!--                         <a href="<?php //echo $back_link; ?>" class="btn btn-default">Back</a>
 -->                      </p>
                      <!-- <form class="forms-sample"> -->
                        
                        <div class="form-group">
                          <label for="exampleInputEmail1">Password</label>
                          <input type="password" class="form-control" id="exampleInputEmail1" placeholder="Enter Password" name="data[password1]" required="" />
                        </div>

                        <div class="form-group">
                          <label for="exampleInputEmail1">Confirm Password</label>
                          <input type="password" class="form-control" id="exampleInputEmail1" placeholder="Confirm Password" name="data[password2]"  required="" />
                        </div>


                        <button type="submit" class="btn btn-success mr-2">Change</button>
                        <!-- <button type="reset" class="btn btn-light">Cancel</button> -->
                        <input type="hidden" name="where[id]" value="<?php echo $id; ?>" />

                      <!-- </form> -->
                    </div>
                  </div>
                </div>

<input type="hidden" name="ccmd" value="user/UserChangePassword" />

   

</div>

</form>             
<?php 
 }else{
  echo '<h2>Invalid Selection!!!</h2>';
 }
?>