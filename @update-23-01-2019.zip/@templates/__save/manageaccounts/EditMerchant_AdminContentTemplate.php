<section class="content-header">
      <h1>
        Edit Merchant
        <!-- <small>Version 2.0</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Edit Merchant</li>
      </ol>
</section>


<section class="content">
<div class="row">


<div class="col-md-8">
          

<div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Edit Merchant</h3>

              <a href="<?php echo BASE_URL; ?>ManageAccounts/ListMerchant" class="btn btn-primary btn-sm pull-right">Back</a>

            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="post">
              <div class="box-body">

                <div class="form-group">
                  <label for="exampleInputEmail1">Account Type</label>
                  <select data-value="<?php echo $merchant_data['account_type']; ?>" class="form-control" name="data[account_type]">
                    <option value="individual">Individual</option>
                    <option value="corporate">Corporate</option>
                  </select>
                </div>
                
                <?php 
                  if ($merchant_data['account_type'] == 'corporate'){
                ?> 
                <div class="form-group">
                  <label for="exampleInputEmail1">Company Name</label>
                  <input type="text" name="data[company_name]" class="form-control" id="exampleInputEmail1" placeholder="Enter Company Name" value="<?php echo $merchant_data['company_name']; ?>">
                </div>
                <?php 
                 }
                ?>

                <div class="form-group">
                  <label for="exampleInputEmail1">Email address</label>
                  <input type="email" name="data[email]" class="form-control" id="exampleInputEmail1" placeholder="Enter email"  value="<?php echo $merchant_data['email']; ?>">
                </div>


                <div class="form-group">
                  <label for="exampleInputEmail1">Surname</label>
                  <input type="text" name="data[surname]" class="form-control" id="exampleInputEmail1" placeholder="Enter Surname"  value="<?php echo $merchant_data['surname']; ?>">
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail1">First Name</label>
                  <input type="text" name="data[first_name]" class="form-control" id="exampleInputEmail1" placeholder="Enter First Name"  value="<?php echo $merchant_data['first_name']; ?>">
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail1">Last Name</label>
                  <input type="text" name="data[last_name]" class="form-control" id="exampleInputEmail1" placeholder="Enter Last Name"  value="<?php echo $merchant_data['last_name']; ?>">
                </div>


                <div class="form-group">
                  <label for="exampleInputEmail1">Account Number</label>
                  <input type="text" name="data[acct_number]" class="form-control" id="exampleInputEmail1" placeholder="Enter Account Number"  value="<?php echo $merchant_data['acct_number']; ?>">
                </div>


                <div class="form-group">
                  <label for="exampleInputEmail1">Bank Name</label>
                  <input type="text" name="data[bank_name]" class="form-control" id="exampleInputEmail1" placeholder="Bank Name"  value="<?php echo $merchant_data['bank_name']; ?>">
                </div>


              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Save</button>
              </div>
            </form>
          </div>

          

</div>

<div class="col-md-3">
  <div style="text-align: center;background-color: #fff;padding-top: 6px;">
    <label>Merchant Secret</label>
  </div>
  <div style="background-color: #000;color: #fff;text-align: center;">
    <?php echo $merchant_data['merch_secret']; ?>
  </div>
</div>

  <!-- /.col -->
</div>
</section>      