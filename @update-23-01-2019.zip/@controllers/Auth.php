<?php 
/**
@Inject(@plugins/apis/UserPlugin,
        @plugins/auth/BackEndLoginPlugin);
*/
class Auth{
 


   function Init(){
     
     InstallTheme('@themes/AdminBackEndFramework');

     // InstallPlugin($this->UserPlugin);
     InstallPlugin($this->BackEndLoginPlugin);

   }

   function Index(){
   	global $redirect;
   	$redirect = 'Auth/LogIn';
    // global $AuthIndex_Redirect;

    // echo 'callled...';

    // $AuthIndex_Redirect = 'Auth/LogIn';
   	// CallAction('LogIn_AdminContent');
   }

   private function CheckLogged(){
    global $session;
    global $redirect;
    
    if (isset($session['user_session'])){
      $redirect = 'User/Dashboard';
    }

   }


   
   function LogIn_AdminContent(){
   	$this->CheckLogged();
   }



   function Page_Destroy(){
   	global $session;
   	// echo 'DES.';
   	if (isset($session['data'])){
      unset($session['data']);
   	}
   }



}