<?php 

class Test{

  

   function Foo(){
   	global $data;
   	global $buffer;


   	$buffer.=$data['msg'];

   	if (isset($data['msg_action'])){
       $buffer.=$data['msg_action'];
   	}

   	$buffer.='
      
      <form method="post">
        <input type="text" name="foo_name" placeholder="Foo Name." /><br />
        <button>Submit.</button>
      </form>

   	';

   	// echo 'Called...';
   }


}