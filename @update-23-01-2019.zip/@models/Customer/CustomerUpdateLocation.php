<?php 
/**
@Inject(@models/entityv2/EntityUpdate);
*/
class CustomerUpdateLocation{



	 function UpdateLocation($lat,$lng,$current_address,$id){

	 	 $this->EntityRead->SetWhere("id=$id");
	 	 $this->EntityUpdate->SetData(array(
           'lat'=>$lat,
           'lng'=>$lng,
           'address'=>$current_address
	 	 ));
	 	 $this->EntityUpdate->DoUpdate('customer');

	 }

}