<?php 
/**
@Inject(@models/Customer/CustomerChangePassword_Action);
*/
class CustomerChangeAccountPassword_Action{


    
    function ChangeAccountPassword_Action(){
    	global $session;
    	$id = $session['customer_session']['id'];
    	// echo $id;
        $this->CustomerChangePassword_Action->ChangePassword_Action($id);
    }


}