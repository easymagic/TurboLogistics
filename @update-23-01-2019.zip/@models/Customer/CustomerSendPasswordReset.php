<?php 
/**
@Inject(@models/entityv2/EntitySendPasswordReset);
*/
class CustomerSendPasswordReset{

  

    function SendPasswordReset(){
      $this->EntitySendPasswordReset->SendPasswordReset('customer','email');
    }


}