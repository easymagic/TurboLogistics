<?php
/**
@Inject(@models/User/UserGetProfile,
        @models/DispatchRequest/DispatchRequestCreateRequest);
*/
class DispatchCreateDispatch{

  

    function CreateDispatch($dispatcher_id,$company_id){
    	global $session;
    	global $DispatchCreateDispatch_Redirect;
    	global $data;
    	global $newID;
    	global $postData;

    	$this->UserGetProfile->GetProfile($dispatcher_id);


    	if (isset($session['customer_session'])){

    	  if ($data['user_data']['dispatch_availability'] == 'free'){

    	  	if ($data['user_data']['parent_id'] == $company_id){

		    	$postData['pickup_address'] = $session['pickup_address'];
		    	$postData['dropoff_address'] = $session['dropoff_address'];

		    	$postData['pickup_lat'] = $session['pickup_lat'];
		    	$postData['pickup_lng'] = $session['pickup_lng'];

		    	$postData['dropoff_lat'] = $session['dropoff_lat'];
		    	$postData['dropoff_lng'] = $session['dropoff_lng'];
		    	$postData['customer_id'] = $session['customer_session']['id'];

		    	$postData['user_id'] = $dispatcher_id;
		    	$postData['user_parent_id'] = $company_id;


	              $this->DispatchRequestCreateRequest->CreateRequest($session['customer_session']['id']);

		    	  $DispatchCreateDispatch_Redirect = 'Dispatch/CaptureAdditionalDetail/' . $newID;	
		    	  $data['message'] = 'Dispatch request created successfully, complete additional detail provided here.';


    	  	}else{

    	  		$data['message'] = 'Invalid request (url-modified)!';
    	  		// $data['error'] = true;
    	  		//https://turboerrands.com/Dispatch/GetDispatchersWithinRadius/6.4439009/3.475083600000062/15
    	  		$DispatchCreateDispatch_Redirect = 'Dispatch/GetDispatchersWithinRadius/' . $session['pickup_lat'] . '/' . $session['pickup_lng'] . '/' . $session['radius'];

    	  	}




    	  }else{

    	  	$data['message'] = 'This dispatcher has already been booked ahead of you before you completed this request, try booking another dispatcher.';
    	  	$data['error'] = true;

    	  }	

         
    	}else{
           
           $data['message'] = 'Please login to complete your dispatch request.';
           $DispatchCreateDispatch_Redirect = 'AuthCustomer/LogIn';


    	}
    }


}