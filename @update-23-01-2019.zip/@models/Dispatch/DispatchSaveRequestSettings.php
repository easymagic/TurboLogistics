<?php 

class DispatchSaveRequestSettings{

    private $radius = 15; //15KM radius.
  
    function SaveRequestSettings(){
    	global $post;
    	global $session;
    	global $DispatchSaveRequestSettings_Redirect;
    	global $data;



    	$session['pickup_address'] = $post['pickup_address'];
    	$session['dropoff_address'] = $post['dropoff_address'];

    	$session['pickup_lat'] = $post['pickup_lat'];
    	$session['pickup_lng'] = $post['pickup_lng'];

    	$session['dropoff_lat'] = $post['dropoff_lat'];
    	$session['dropoff_lng'] = $post['dropoff_lng'];

    	$session['dispatch_distance'] = $post['dispatch_distance'];

    	$session['radius'] = $this->radius;

    	$DispatchSaveRequestSettings_Redirect = 'Dispatch/GetDispatchersWithinRadius/' . $session['pickup_lat'] . '/' . $session['pickup_lng'] . '/' . $this->radius;

    	$data['message'] = 'Dispatch Settings Saved.';

    }


}