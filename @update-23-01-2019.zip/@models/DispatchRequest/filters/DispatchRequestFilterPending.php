<?php 
/**
@Inject(@models/entityv2/EntityRead);
*/

class DispatchRequestFilterPending{

   
    function FilterPending(){
    	$this->EntityRead->SetWhere("dispatch_status='pending'");
    }

}