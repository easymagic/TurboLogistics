<?php 
/**
@Inject(@models/entityv2/EntityAccountCreate,
        @models/User/UserUpdateCompanyLogo);
*/

class UserRegister{

  


   function Register(){
   	 global $post;
   	 global $postData;
   	 global $newID;
   	 
   	 $this->EntityCheckPassword->SetData($post);
   	 $this->EntityAccountCreate->SetData($postData);
   	 $this->EntityAccountCreate->SetDuplicateField('email');
     $this->EntityAccountCreate->AccountCreate('user');

     if ($postData['role'] == 'company' && !empty($newID)){
        $this->UserUpdateCompanyLogo->UpdateCompanyLogo($newID);
     }

   }


}