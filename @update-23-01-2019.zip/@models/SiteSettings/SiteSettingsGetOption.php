<?php 
/**
@Inject(@models/entityv2/EntityReadOne);
*/
class SiteSettingsGetOption{

  

  function GetOption($name){
    global $data;
    $this->EntityReadOne->ReadOne('site_settings');
    return $data['site_settings_data'][$name];
  }


}