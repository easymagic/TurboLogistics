<?php 
/**
@Inject(@models/entityv2/EntityUpdate);
*/
class SiteSettingsUpdateOption_Action{

  
  function UpdateOption_Action($name){
     global $data;
     global $postData;
     // global $redirect;
     // global $redirectSiteSettingsUpdateOption;
     $data['error'] = false;
     $this->EntityRead->SetWhere("id=1");
     $this->EntityUpdate->SetData(array(
      $name=>$postData[$name]
     ));
     $this->EntityUpdate->DoUpdate('site_settings');
     $data['message'] = 'Option updated';

     // $redirect = $redirectSiteSettingsUpdateOption;
     
  }

}