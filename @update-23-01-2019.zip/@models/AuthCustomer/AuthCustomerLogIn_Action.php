<?php 
/**
@Inject(@models/Customer/CustomerLogIn_Action);
*/
class AuthCustomerLogIn_Action{
   

    function LogIn_Action(){
    	// echo 'called.';
     global $AuthCustomerLogIn_Action_Redirect;	
     global $session;
     global $data;	
     
     $this->CustomerLogIn_Action->LogIn_Action();

     if (!isset($data['error']) || !$data['error']){

     	if (isset($session['intent_action'])){
           $AuthCustomerLogIn_Action_Redirect = $session['intent_action'];
           unset($session['intent_action']);
           $data['message'] = 'Login successful, Complete your dispatch request.';
     	} 
     
       

     }

    }


}