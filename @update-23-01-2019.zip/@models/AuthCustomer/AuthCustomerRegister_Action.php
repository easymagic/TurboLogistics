<?php 
/**
@Inject(@models/Customer/CustomerRegister_Action);
*/
class AuthCustomerRegister_Action{

     

     function Register_Action(){
       $this->CustomerRegister_Action->Register_Action();
     }


}