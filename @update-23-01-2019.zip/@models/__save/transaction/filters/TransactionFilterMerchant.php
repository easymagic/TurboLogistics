<?php 

class TransactionFilterMerchant{

  


   function FilterMerchant($merchant_id){//
   	global $db_where;
   	global $transactionFilters;

   	$transactionFilters[] = "merchant_id = '$merchant_id'";
     
    $db_where = " where (" . implode(' and ', $transactionFilters) . ") "; 

   }



}