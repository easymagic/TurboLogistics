<?php 

/**

@Inject(@services/file/FileUpload,
        @services/Db);

*/

class CrudService{

  

  private function CheckFileUpload(&$request){
    if (isset($_FILES)){
      foreach ($_FILES as $k=>$hnd){
       if ($this->FileUpload->DoUpload($hnd,$k)){
         $request['data'][$k] = $this->FileUpload->GetUploadedFile();
       }
      }
    }
  }


  private function CheckDuplicateRecord($entity,&$request,$message='Duplicate Record!'){
    
    if (isset($request['check'])){
      
      $key = $request['check'];
      $value = $request['data'][$key];
      $record = $this->Db->Where($key,$value)->Get($entity);
      
      if (count($record) > 0){
        throw new Exception($message, 1);
      }

    }

  }

  function DoAdd($entity,$data){

    $this->CheckDuplicateRecord($entity,$data);
    $this->CheckFileUpload($data);

    $config = array();

    include('config/on-data-in.php');
    if (isset($config[$entity])){
       foreach ($config[$entity] as $k=>$v){
         $data['data'][$k] = $v;
       }
    }


    $this->Db->Insert($entity,$data['data']);    
    return array('message'=>'New Record Added...','id'=>$this->Db->InsertID());

  }

  function DoUpdate($entity,$id,$data){
    $this->CheckFileUpload($data);
    $this->Db->Where('id',$id);
    
    
    $config = array();
    include('config/on-seek.php');
    if (isset($config[$entity])){
      foreach ($config[$entity] as $k=>$v){
        $this->Db->And($v[0],$v[1]);  
      }
    }

    include('config/on-data-in.php');
    if (isset($config[$entity])){
       foreach ($config[$entity] as $k=>$v){
         $data['data'][$k] = $v;
       }
    }

    // print_r($data);

    
    $this->Db->Update($entity,$data['data']);
    return array('message'=>'Record Saved....');
  }

  function DoDelete($entity,$id){
    // if (!isset($request['id']))throw new Exception("id-seek-param required!", 1);
    // $id = $request['id'];
    $this->Db->Where('id',$id);

    $config = array();
    include('config/on-seek.php');
    if (isset($config[$entity])){
      foreach ($config[$entity] as $k=>$v){
        $this->Db->And($v[0],$v[1]);  
      }
    }

    $this->Db->Delete($entity);
    // $this->RequestResponse->SetResponse('message','Record Removed.');
    return array('message'=>'Record Removed....');    
  }

  function GetRecords($entity){

    $config = array();
    include('config/on-seek.php');
    if (isset($config[$entity])){
      foreach ($config[$entity] as $k=>$v){
        $this->Db->And($v[0],$v[1]);  
      }
    }
    
    return $this->Db->Get($entity);
  }

  function GetRecord($entity,$id){
   
   $this->Db->Where('id',$id);
   
    $config = array();
    include('config/on-seek.php');
    if (isset($config[$entity])){
      foreach ($config[$entity] as $k=>$v){
        $this->Db->And($v[0],$v[1]);  
      }
    }

   $dt = $this->Db->Get($entity);
   if (count($dt) > 0){
    return $dt[0];
   }else{
    return $dt; 
   }
   
  }

  function GetRecordCount($entity,$alias='recordCount'){
   
    $config = array();
    include('config/on-seek.php');
    if (isset($config[$entity])){
      foreach ($config[$entity] as $k=>$v){
        $this->Db->And($v[0],$v[1]);  
      }
    }

    $record = $this->Db->DoCount($entity,$alias); //recordCount
    return $record[0]['recordCount'];

  }


  function GetRecordSum($entity,$field,$alias='sumTotal'){
   
    $config = array();
    include('config/on-seek.php');
    if (isset($config[$entity])){
      foreach ($config[$entity] as $k=>$v){
        $this->Db->And($v[0],$v[1]);  
      }
    }

    $record = $this->Db->DoSum($entity,$field,$alias); //recordCount
    return $record[0]['sumTotal'];

  }



  function HandleCrud($entity,$id='',$field=''){

    if ($this->IsReadAction($entity,$id)){
       return array($entity . '_data'=>$this->GetRecords($entity));
    }else if ($this->IsReadOneAction($entity,$id)){
       return array($entity . '_data'=>$this->GetRecord($entity,$id));
    }else if ($id == 'count'){
       return array($entity . '_count'=>$this->GetRecordCount($entity));
    }else if ($id == 'sum' && !empty($field) && !is_numeric($field)){
       return array($entity . '_sum'=>$this->GetRecordSum($entity,$field));
    }else{  
      return array();
    }
    
  }

  function IsAddAction($entity,$id){
   return (empty($id) && !empty($entity));
  }

  function IsUpdateAction($entity,$id){
   return (!empty($entity) && !empty($id)); 
  }

  function IsDeleteAction($verb){
   return ($verb == 'delete');
  }

  function IsReadAction($entity,$id){
   return (empty($id) && !empty($entity));
  }

  function IsReadOneAction($entity,$id){
   return (!empty($entity) && !empty($id) && is_numeric($id));
  }



  function HandleCrudAction($entity,$id='',$verb='',$verb2=''){
   
   if (empty($verb)){

    if ($this->IsAddAction($entity,$id)){
       return $this->DoAdd($entity,$_REQUEST);
    }else if ($this->IsUpdateAction($entity,$id)){
       return $this->DoUpdate($entity,$id,$_REQUEST);
    }else if ($this->IsDeleteAction($entity,$id,$verb)){
       return $this->DoDelete($entity,$id);
    }


   }else if ($this->IsDeleteAction($verb)){

     return $this->DoDelete($entity,$id);

   }else if ($id == 'find' && !empty($verb) && !empty($verb2)){  
      $this->Db->Where($verb,$verb2);
      return array($entity . '_data'=>$this->Db->Get($entity));
   }



  }


}