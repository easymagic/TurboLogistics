<?php 

/**

@Inject(@services/Db);

*/

class OtherPlugin{



  function SetEntity($entity=''){

  }


  function Amount_Validate(&$amt){
    $amt-=10;
    echo "Called on self. $amt";
  }




}


