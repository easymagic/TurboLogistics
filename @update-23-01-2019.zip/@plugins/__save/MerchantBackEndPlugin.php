<?php 

/**

@Inject(@templates/backend/Admin_HTML_StartTemplate,
        @templates/backend/Admin_HeaderTemplate,
        @templates/backend/merchant/Merchant_SideBarTemplate,
        @templates/backend/Admin_Content_PreStartTemplate,
        @templates/backend/Admin_Content_PreStopTemplate,
        @templates/backend/Admin_FooterTemplate,
        @templates/backend/Admin_HTML_StopTemplate,
        @plugins/AdminBackEndPlugin);

*/


class MerchantBackEndPlugin{
  
 // function Framework_Start(){
 //    global $session;
 //    global $data;
 //    global $logged;
 //    global $session_type;
 //    global $merchantID;

 //    $logged = false;
 //    $session_type = 'merchant';

 //    // echo $session_type;
    
 //    // $data['role'] = '';
 //    if (isset($session['merchant_session'])){
 //      // echo 'called.';
 //       $data['role'] = $session['merchant_session']['role'];
 //       $logged = true;
 //       $data['session_type'] = $session_type;
 //       // echo $data['session_type'];
 //       $merchantID = $session['merchant_session']['id'];
 //    }



 // } 

 function Admin_HTML_Start(){
  global $buffer;
  $buffer.=$this->Admin_HTML_StartTemplate->View();
 }  

 function Admin_Header(){
  global $buffer;
  $buffer.=$this->Admin_HeaderTemplate->View();
 }

 function Admin_SideBar(){
  global $buffer;
  $buffer.=$this->Merchant_SideBarTemplate->View();
 }

 function Admin_Content_PreStart(){
  global $buffer;
  $buffer.=$this->Admin_Content_PreStartTemplate->View();
 }

 function Admin_Content_PreStop(){
  global $buffer;
  $buffer.=$this->Admin_Content_PreStopTemplate->View();
 }

 function Admin_Footer(){
  global $buffer;
  $buffer.=$this->Admin_FooterTemplate->View();
 }

 function Admin_HTML_Stop(){
  global $buffer;
  $buffer.=$this->Admin_HTML_StopTemplate->View();
 }

 

}