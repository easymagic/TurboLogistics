<?php 
/**
@Inject(@models/Customer/CustomerLogIn_Action);
*/
class AuthCustomerLogin_Action{
   

    function LogIn_Action(){
    	// echo 'called.';
     $this->CustomerLogIn_Action->LogIn_Action();
    }


}