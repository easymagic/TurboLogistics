<?php
/**
@Inject(@models/User/UserChangePassword,
        @models/User/UserChangePasswordReset,
        @models/User/UserGetBusyStatus,
        @models/User/UserGetDispatchWithinRadius,
        @models/User/UserGetList,
        @models/User/UserGetProfile,
        @models/User/UserLogOut,
        @models/User/UserLogIn,
        @models/User/UserSendPasswordReset,
        @models/User/UserRegister,
        @models/User/UserUpdateLocation,
        @models/User/UserUpdateCompanyLogo,
        @models/User/UserUpdatePassport,
        @models/User/UserUpdateProfile);
*/

class UserPlugin{

   
    private function RedirectToDomain(){
     global $redirect;
     $redirect = 'User/GetList';	
    }

    function ChangePassword_Action($id){
       $this->UserChangePassword->ChangePassword($id);
    }

    function ChangePasswordReset_Action($id,$check){
      $this->UserChangePasswordReset->ChangePasswordReset($id,$check);
    }

    function GetList(){
    	$this->UserGetList->GetList();
    }

    function GetProfile($id){
      $this->UserGetProfile->GetProfile($id);
    }

    function LogOut(){
      global $redirect;
      $redirect = 'User/LogIn';	
      $this->UserLogOut->LogOut();	
    }

    function LogIn_Action(){
     $this->UserLogIn->LogIn(); 	
    }

    function SendPasswordReset(){
      $this->UserSendPasswordReset->SendPasswordReset();
    }

    function Register(){
      $this->UserRegister->Register();	
    }

    function UpdateLocation($lat,$lng,$current_address,$id){
      $this->UserUpdateLocation->UpdateLocation($lat,$lng,$current_address,$id);
    }

    function UpdateCompanyLogo($id){
      $this->UserUpdateCompanyLogo->UpdateCompanyLogo($id);	
    }

    function UpdatePassport($id){
      $this->UserUpdatePassport->UpdatePassport($id);
    }

    // function UpdateProfile($id){
    //   $this->RedirectToDomain();	
    //   $this->UserUpdateProfile->UpdateProfile($id);
    // }


    function UpdateProfile($id){
      $this->GetProfile($id);
    }

    function UpdateProfile_Action($id){
      $this->RedirectToDomain();	
      $this->UserUpdateProfile->UpdateProfile($id);
    }

    function UpdateAccount(){
     global $session;
     $this->UpdateProfile($session['user_session']['id']);
    }

    function UpdateAccount_Action(){
     global $session;
     $this->UpdateProfile_Action($session['user_session']['id']);
    }




}