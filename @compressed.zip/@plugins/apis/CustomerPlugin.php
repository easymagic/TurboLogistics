<?php
/**
@Inject(@models/Customer/CustomerChangePassword,
        @models/Customer/CustomerChangePasswordReset,
        @models/Customer/CustomerGetList,
        @models/Customer/CustomerGetProfile,
        @models/Customer/CustomerLogOut,
        @models/Customer/CustomerLogIn,
        @models/Customer/CustomerSendPasswordReset,
        @models/Customer/CustomerRegister,
        @models/Customer/CustomerUpdateLocation,
        @models/Customer/CustomerUpdateProfile);
*/

class CustomerPlugin{

   
    private function RedirectToDomain(){
     global $redirect;
     $redirect = 'Customer/GetProfile';	
    }

    function ChangePassword_Action($id){
       $this->CustomerChangePassword->ChangePassword($id);
    }

    function ChangePasswordReset_Action($id,$check){
      $this->CustomerChangePasswordReset->ChangePasswordReset($id,$check);
    }

    function GetList(){
    	$this->CustomerGetList->GetList();
    }

    function GetProfile($id){
      $this->CustomerGetProfile->GetProfile($id);
    }

    function LogOut(){
      global $redirect;
      $redirect = 'Customer/LogIn';	
      $this->CustomerLogOut->LogOut();	
    }

    function LogIn_Action(){
     $this->CustomerLogIn->LogIn(); 	
    }

    function SendPasswordReset(){
      $this->CustomerSendPasswordReset->SendPasswordReset();
    }

    function Register(){
      $this->CustomerRegister->Register();	
    }

    function UpdateLocation($lat,$lng,$current_address,$id){
      $this->CustomerUpdateLocation->UpdateLocation($lat,$lng,$current_address,$id);
    }

    // function UpdateCompanyLogo($id){
    //   $this->CustomerUpdateCompanyLogo->UpdateCompanyLogo($id);	
    // }

    // function UpdatePassport($id){
    //   $this->UserUpdatePassport->UpdatePassport($id);
    // }

    function UpdateProfile($id){
      $this->GetProfile($id);
    }

    function UpdateProfile_Action($id){
      $this->CustomerUpdateProfile->UpdateProfile($id);
    }

    function UpdateAccount(){
     global $session;
     $this->UpdateProfile($session['customer_session']['id']);
    }

    function UpdateAccount_Action(){
     global $session;
     $this->UpdateProfile_Action($session['customer_session']['id']);
    }




}