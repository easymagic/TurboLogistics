<?php 
/**
@Inject(@models/SiteSettings/SiteSettingsGetOption,
        @models/SiteSettings/SiteSettingsUpdateOption);
*/
class SiteSettingsPlugin{

    
    function UpdateOption_Action($name){
      $this->SiteSettingsUpdateOption->UpdateOption($name);
    }


}