<?php 


class TestPlugin{

  private $entity;

  function SetEntity($ent){
   $this->entity = $ent;
  } 

  function Greet_Inject($view){
    // print_r($view);
    echo 'Injecting...';
  }

  function Greet_Permission(){
    // echo 'Authenticating ...';
    // throw new Exception("Can't access greet!!");
  }




}


