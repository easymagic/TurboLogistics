<?php 
/**
@Inject(@models/entityv2/EntityAccountCreate);
*/

class UserRegister{

  


   function Register(){
   	 global $post;
   	 global $postData;
   	 
   	 $this->EntityCheckPassword->SetData($post);
   	 $this->EntityAccountCreate->SetData($postData);
   	 $this->EntityAccountCreate->SetDuplicateField('email');
     $this->EntityAccountCreate->AccountCreate('user');
   }


}