<?php 
/**
@Inject(@models/entityv2/EntityUpdate);
*/
class SiteSettingsUpdateOption{

  
  function UpdateOption($name){
     global $data;
     global $postData;
     $data['error'] = false;
     $this->EntityRead->SetWhere("id=1");
     $this->EntityUpdate->SetData(array(
      $name=>$postData[$name]
     ));
     $data['message'] = 'Option updated';
  }

}