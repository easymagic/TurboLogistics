<?php 
/**
@Inject(@models/entityv2/EntityChangePasswordReset);
*/


class CustomerChangePasswordReset{
  


    function ChangePasswordReset($id,$check){
      $this->EntityChangePasswordReset->ChangePasswordReset('customer',$id,$check);
    }


}