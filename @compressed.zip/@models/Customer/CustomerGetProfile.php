<?php 
/**
@Inject(@models/entityv2/EntityReadOne);
*/


class CustomerGetProfile{


  function GetProfile($id){
   $this->EntityRead->SetWhere("id=$id");	
   $this->EntityReadOne->ReadOne('customer');
  }


}