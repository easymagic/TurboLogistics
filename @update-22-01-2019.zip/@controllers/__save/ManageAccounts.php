<?php 

/**

@Inject(@plugins/AdminBackEndPlugin,
        @plugins/admin/ManageAccountsPlugin,
        @plugins/session/CheckAdminSessionLoggedPlugin,
        @plugins/dashboard/DashboardPlugin);


*/


class ManageAccounts{
  

  function Init(){
    InstallPlugin($this->ManageAccountsPlugin);
    InstallPlugin($this->AdminBackEndPlugin);
    
    InstallPlugin($this->CheckAdminSessionLoggedPlugin);
    InstallPlugin($this->DashboardPlugin);

    InstallTheme('@themes/AdminBackEndFramework');

  }
  
  ////dashboard///////
  function Dashboard_AdminContent(){

  }

  ////admin/////////////
  function ListAdmin_AdminContent(){

  }

  function AddAdmin_AdminContent(){

  }

  function ChangeAdminPassword_AdminContent($id=''){

  }

  function ChangePassword_AdminContent(){

  }

  ////merchant//////////

  function AddMerchant_AdminContent(){

  }

  function EditMerchant_AdminContent($id=''){

  }

  function ChangeMerchantPassword_AdminContent($id){

  }

  function ListMerchant_AdminContent(){

  }


}
 