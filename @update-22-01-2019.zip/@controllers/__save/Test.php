<?php 
/**
@Inject(@plugins/global/GlobalPlugin);
*/

class Test{

 
 function Init(){
 	
 	InstallPlugin($this->GlobalPlugin);

 }  

 
  
 // function GateWay(){
 //   global $data;

 //   // $data['gway'] = 'InterPAY.ABC.AKL';
 // }

 // function Gway(){

 // }



}