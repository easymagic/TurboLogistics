<?php 
/**
@Inject(@plugins/client/ClientFrontEndPlugin);
*/
class Home{

   
    function Init(){
      InstallPlugin($this->ClientFrontEndPlugin);	
      InstallTheme('@themes/ClientFrontendFramework');
    } 

   
   function Index_ClientContent(){
   	global $buffer; 
   	// $buffer.='Default ... 123.';
   }



}