<?php 

function __($k){
 global $postData;
 global $post;
 if (isset($postData[$k])){
    return $postData[$k];
 }else if (isset($post[$k])){
    return $post[$k];
 }else{
    return '';
 }
}

// function _($k){
//  global $post;
//  if (isset($post[$k])){
//     echo $post[$k];
//  }
// }


function Iterate($key){
  $key_ptr = $key . '_index_ptr_';
  global $_global_index_pointer;
  global $_global_object;
  global $data;
  global $$key_ptr;

  if (!isset($_global_index_pointer)){
    $_global_index_pointer = -1;
  }

  if (!isset($_global_object)){
    $_global_object = array();
  }

  if (!isset($$key_ptr)){
    $$key_ptr = -1;
  }

  if (isset($data[$key])){
    ++$$key_ptr;
    $_global_index_pointer = $$key_ptr;
    
    if (isset($data[$key][$_global_index_pointer])){
      $_global_object = $data[$key][$_global_index_pointer];
      CallAction($key . '_Field_Transform');
    }

    return ($$key_ptr < sizeof($data[$key]));
  }else{
  	$_global_object = array();
    return false;
  }

}

function GetRow($key){
 global $_global_object;
 if (isset($_global_object[$key])){
  return $_global_object[$key]; 
 }else{
  return '';	
 }	
}

function SetRow($k,$v){
 global $_global_object;
 $_global_object[$k] = $v;
}

function GetRowCount(){
 global $_global_index_pointer;
 return ($_global_index_pointer + 1);
}


function PersistData(){
  global $data;
  global $session;

  if (!isset($session['data'])){
    $session['data'] = array();
  }

  if (isset($data)){
	  foreach ($data as $k=>$v){
	    $session['data'][$k] = $v;
	  }
  }

}


function InstallTheme($thm){
  global $themes;
  $themes[] = $thm;
}


function RunThemes(){
  
  global $themes;

  foreach ($themes as $theme){
    require($theme . '.php');
  }
    //@frameworks
    // $dir = scandir('@themes');
    // $dir = array_diff($dir, array('.','..'));
    // foreach ($dir as $k=>$v){
    //   require('@themes/' . $v);
    // }
}


function InstallPlugin($obj){
  global $plugins;
  $plugins[] = $obj;
}

function PushThread($obj){
 global $threads;
 $threads[] = $obj;
}

function PushLib($lib_){
  global $libs;
  $libs[] = $lib_;
}

function LoadLibs(){
  global $libs;
  foreach ($libs as $lib){
   require_once($lib . '.php');
  }
}

function DefineGlobal($name,&$vl){
 $GLOBALS[$name] = $vl;
 // global $post;
 // print_r($post);
 // print_r($vl);
}

function RunThreads(){
  global $threads;
  foreach ($threads as $k=>$thread){
    CallProxy($thread,'Run');  //must have a run method just like what we have in java.
  }
}


function StartBuffer(){
 ob_start();
}

function GetBuffer(){
 $r = ob_get_contents();
 ob_end_clean();
 return $r;
}

function ActionTrigerred(){
	return (isset($_POST) && !empty($_POST));
}

function EndsWith($str,$ends){
 $end = substr($str, -1 * strlen($ends));
 $end = strtolower($end);
 if ($end == strtolower($ends)){
  return true;
 }else{
  return false;
 }
}



class InjectViewClass{
  
   private $view_ = null;

   function __construct($view){
     $this->view_ = $view;
   }


   function View(){

   	 global $dependencyData;
   	 global $data;
     global $session;

    
      $file = $this->view_ . '.php';
      // print_r($data);

      if (file_exists($file)){
        $tmp = null;

        if (isset($data['data'])){
          $tmp = $data['data'];
          unset($data['data']);
          $data['data_renamed'] = $tmp;
        }
        
        if (isset($session['data'])){
         extract($session['data']);
        }

        if (isset($dependencyData['data'])){
          $tmp = $dependencyData['data'];
          unset($dependencyData['data']);
          $dependencyData['data_renamed'] = $tmp;
        }
        extract($dependencyData);
        extract($data);
        StartBuffer();
        include($file);
        return GetBuffer();
      }else{
      	return '';
      }

   }


}


function InjectClass($cls){
 return DIContainer::GetInstance()->InjectClass($cls);
}

function CallProxy($obj,$method,$args=array()){

  	if (is_object($obj) && method_exists($obj, $method)){
      call_user_func_array(array($obj,$method), $args);
  	}
    
}


function CallUCModel($action){ //automatically handle redirects;
 global $routeArgs;
 global $redirect;
 global $data;
 // global $routeAction;
 // global $routeName;
 global $routeNameOriginal;
 global $aliasModel;
 //global $routeActionOriginal;
 if (isset($aliasModel) && !empty($aliasModel)){
   $key = '@models/' . $aliasModel . '/' . $aliasModel . $action;
   $red = $aliasModel . $action . '_Redirect';
   global $$red;
 }else{
   $key = '@models/' . $routeNameOriginal . '/' . $routeNameOriginal . $action;	
   $red = $routeNameOriginal . $action . '_Redirect';
   global $$red;
 }
 
 // echo $key . '<br />';
 $obj = InjectKey($key);
 if (!is_null($obj)){
   CallProxy($obj,$action,$routeArgs);
   if (isset($$red) && !empty($$red)){
    if (!isset($data['error']) || !$data['error']){
	   $redirect = $$red;
    }
   } 

 }


}

function CallAction($action,$ucModel=false){
  global $routeObject;
  global $routeArgs;
  global $plugins;
  global $buffer;
  global $routeAction;
  global $routeName;
  
  if ($ucModel){
   CallUCModel($action);
   // echo '1.';
  }
  
  PersistData();
  RunThreads();


  foreach ($plugins as $k=>$v){
   CallProxy($v,$action,$routeArgs);
  }
  CallProxy($routeObject,$action,$routeArgs);
  PersistData();

  RunThreads();

  //call ui template
  $file = '@templates/' . strtolower($routeName) . '/' . $action . 'Template';
  $obj = InjectKey($file);

  if (!is_null($obj)){
    $buffer.=$obj->View();
  }
      
}


function InjectKey($depStr){
 
  global $dependencyData;	
  
  $file = $depStr . '.php';
  // echo $file;
  $obj  = null;

  if (file_exists($file)){
    

    $r = explode('/', $depStr);

    $package = array_shift($r);

    $cls = end($r);

    if (!isset($dependencyData[$cls])){

        if ($package == '@templates' || substr($cls, -8) == 'Template'){ 

          if (file_exists($depStr . '.php')){
            $dependencyData[$cls] = new InjectViewClass($depStr);
            $obj =  $dependencyData[$cls]; 
          }else{
            $obj = null;
          }

 
        }else{   

          require_once($file);                         

          $dependencyData[$cls] = InjectClass($cls);   

          
          $obj =  $dependencyData[$cls]; 

        }



    }else{

      $obj =  $dependencyData[$cls]; 
      
    }


  }

  return $obj;

}





