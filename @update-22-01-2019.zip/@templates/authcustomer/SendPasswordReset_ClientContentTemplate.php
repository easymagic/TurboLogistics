<section class="main__middle__container">
  <div class="row no_padding no-margin nothing nice__title2 blog text-center">
    <div class="container">
      <h2>Password Reset</h2>
      <span class="sep"></span>
      <p><font color="#000000">Request</font></p>
    </div>
  </div>
  <section class="recent-posts">
    <div class="container">

      <div class="row" style="padding-top: 0;">
        <div class="col-md-8 col-md-offset-2"> 
          <h3>Request Password Reset</h3>
          <hr>
          <!-- <p>Please enter your tracking ID below.</p> -->
          <p id="feedback"></p>
          <form role="form" id="contact-form" name="contact-form" method="post" action="" class="contact-form">
            
            <div class="form-group">
              <label class="sr-only" for="exampleInputEmail1">E-mail:</label>
              <input type="email" class="form-control" id="subject" name="email" placeholder="E-mail">
            </div>

            
            <input id="submit-button" type="submit" class="btn btn-sm btn-info" value="Send">


            <a href="<?php echo BASE_URL; ?>AuthCustomer/LogIn" style="font-size: 15px;">Login</a>&nbsp;|&nbsp;
            <a href="<?php echo BASE_URL; ?>AuthCustomer/Register" style="font-size: 15px;">Register</a>
          </form>
          
          
        </div>
      </div>
    </div>
  </section>
</section>


