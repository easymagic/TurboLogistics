<section class="content-header">
      <h1>
        Add Company Staff
        <!-- <small>Version 2.0</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Add Company Staff</li>
      </ol>
</section>


<section class="content">
<div class="row">


<div class="col-md-8">
          




<div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Add Company Staff</h3>

              <a href="<?php echo BASE_URL; ?>CompanyStaff/GetList" class="btn btn-primary btn-sm pull-right">Back</a>

            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="post">
              <div class="box-body">

<!--                 <div class="form-group">
                  <label for="exampleInputEmail1">Account Type</label>
                  <select class="form-control" name="data[account_type]">
                    <option value="individual">Individual</option>
                    <option value="corporate">Corporate</option>
                  </select>
                </div>
 -->

                <div class="form-group">
                  <label for="exampleInputEmail1">Email address</label>
                  <input type="text" name="data[email]" class="form-control" id="exampleInputEmail1" placeholder="Enter email">
                </div>


                <div class="form-group">
                  <label for="exampleInputEmail1">Username</label>
                  <input type="text" name="data[username]" class="form-control" id="exampleInputEmail1" placeholder="Enter Surname">
                </div>


                <div class="form-group">
                  <label for="exampleInputPassword1">Password</label>
                  <input type="password" name="password1" class="form-control" id="exampleInputPassword1" placeholder="Password">
                </div>

                <div class="form-group">
                  <label for="exampleInputPassword1">Confirm Password</label>
                  <input type="password" name="password2" class="form-control" id="exampleInputPassword1" placeholder="Password">
                </div>                

              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
          </div>

          

</div>

  <!-- /.col -->
</div>
</section>      