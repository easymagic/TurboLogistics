<?php 

/**

@Inject(@services/RequestResponse,
        @services/entity/EntityCommit,
        @services/CrudService,
        @services/AuthorizationService);

*/

class APIPlugin{

  private $entity;


  function SetEntity($entity=''){
    $this->entity = $entity;
  }

  function GetScope(){
    return 'private';
  }
  

  function Collection_Payload($requestData){
    foreach ($requestData as $k=>$v){

      $_REQUEST[$k] = $v;

    }
    $this->RequestResponse->SetRequest($requestData);
    // print_r($this->RequestResponse->GetRequest());
    // echo 'called.';
    // print_r(getallheaders());
    // print_r(headers_list());

    // print_r(http_get_request_headers());
    // print_r(get_headers());
    // print_r(headers_sent());
  }

  function Collection_Action($entity='',$id='',$verb='',$verb2=''){
    return $this->CrudService->HandleCrudAction($entity,$id,$verb,$verb2);
  }

  function Collection_Inject($entity='',$id='',$field=''){
    return $this->CrudService->HandleCrud($entity,$id,$field);
    
  }


  function Collection_JSON($json){
    return json_encode($json);
  }




}


