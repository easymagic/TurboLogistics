<?php
/**
@Inject(@models/User/UserChangePassword,
        @models/User/UserChangePasswordReset,
        @models/User/UserGetBusyStatus,
        @models/User/UserGetDispatchWithinRadius,
        @models/User/UserGetList,
        @models/User/UserGetProfile,
        @models/User/UserLogOut,
        @models/User/UserLogIn,
        @models/User/UserSendPasswordReset,
        @models/User/UserRegister,
        @models/User/UserUpdateLocation,
        @models/User/UserUpdateCompanyLogo,
        @models/User/UserUpdatePassport,
        @models/User/UserUpdateProfile,
        @models/User/metrics/UserGetCount,
        @models/DispatchRequest/filters/DispatchRequestFilterBooked,
        @models/DispatchRequest/filters/DispatchRequestFilterCardPayment,
        @models/DispatchRequest/filters/DispatchRequestFilterCashPayment,
        @models/DispatchRequest/filters/DispatchRequestFilterDropped,
        @models/DispatchRequest/filters/DispatchRequestFilterDroppedOff,
        @models/DispatchRequest/filters/DispatchRequestFilterPicked,
        @models/DispatchRequest/filters/DispatchRequestFilterPending,
        @models/DispatchRequest/metrics/DispatchRequestGetCount,
        @models/DispatchRequest/metrics/DispatchRequestGetSum,
        @models/Customer/metrics/CustomerGetCount,
        @models/User/filters/UserFilterCompanyStaff,
        @models/User/filters/UserFilterCompany,
        @models/User/filters/UserFilterStaff,
        @models/User/filters/UserFilterDispatcher,
        @models/User/UserEnableStatus,
        @models/User/UserDisableStatus);
*/

class UserPlugin{

   
    private function RedirectToDomain(){
     global $redirect;
     global $me;
     global $data;

     // print_r($data);
     
     if (!isset($data['error']) || !$data['error']){
      $redirect = $me . '/GetList';
     }
     	
    }

    function Dashboard_AdminContent(){
    	// echo 'DASH';
    	global $data;
      global $parent_id;

    	
      // $this->EntityRead->SetWhere("parent_id=$parent_id");
      $data['user_count'] = $this->UserGetCount->GetCount();
    	$data['customer_count'] = number_format($this->CustomerGetCount->GetCount());

    	$this->EntityRead->SetWhere("parent_id=$parent_id");
      $this->UserFilterDispatcher->FilterDispatcher();
    	$data['dispatcher_count'] = number_format($this->UserGetCount->GetCount());

    	$this->EntityRead->SetWhere("user_parent_id=$parent_id");
      $this->DispatchRequestFilterPending->FilterPending(); //user_parent_id
    	$data['pending_dispatch_count'] = number_format($this->DispatchRequestGetCount->GetCount());

    	$this->EntityRead->SetWhere("user_parent_id=$parent_id");
      $this->DispatchRequestFilterDroppedOff->FilterDroppedOff();
    	$data['confirmed_dispatch_count'] = number_format($this->DispatchRequestGetCount->GetCount());



    }

    function ChangePassword($id){
     $this->GetProfile($id);
    }

    function ChangeAccountPassword(){
    	global $session;
    	$id = $session['user_session']['id'];
    	$this->ChangePassword($id);
    }

    function ChangePassword_Action($id){
       $this->UserChangePassword->ChangePassword($id);
       $this->RedirectToDomain();
    }

    function ChangeAccountPassword_Action(){
      global $session;
      global $redirect;
      $id = $session['user_session']['id'];
      $this->ChangePassword_Action($id);
      $redirect = 'User/Dashboard'; 
    }

    function ChangePasswordReset_Action($id,$check){
      $this->UserChangePasswordReset->ChangePasswordReset($id,$check);
    }

    function GetList(){
    	global $db_where;
    	// echo $db_where;
    	// die($db_where);
    	// $this->UserGetList->GetList();
    }

    function GetProfile($id){
      $this->UserGetProfile->GetProfile($id);
    }

    function LogOut(){
      global $redirect;
      $redirect = 'Auth/LogIn';	
      $this->UserLogOut->LogOut();	
    }

    function LogIn_Action(){
     $this->UserLogIn->LogIn(); 	
    }

    function Index_Action(){
      $this->LogIn_Action();	
    }

    function SendPasswordReset(){
      $this->UserSendPasswordReset->SendPasswordReset();
    }

    function Register_Action(){
      global $db_sql;	
      global $parent_id;
      global $postData;

      $postData['parent_id'] = $parent_id;
      $this->UserRegister->Register();
      // echo $db_sql;
      $this->RedirectToDomain();	
    }

    function UpdateLocation($lat,$lng,$current_address,$id){
      $this->UserUpdateLocation->UpdateLocation($lat,$lng,$current_address,$id);
    }

    function UpdateCompanyLogo_Action($id){
      $this->UserUpdateCompanyLogo->UpdateCompanyLogo($id);	
      $this->RedirectToDomain();
    }

    function UpdatePassport_Action($id){
      $this->UserUpdatePassport->UpdatePassport($id);
      $this->RedirectToDomain();
    }

    // function UpdateProfile($id){
    //   $this->RedirectToDomain();	
    //   $this->UserUpdateProfile->UpdateProfile($id);
    // }


    function UpdateProfile($id){
      $this->GetProfile($id);
    }

    function UpdateProfile_Action($id){
      // $this->RedirectToDomain();	
      $this->UserUpdateProfile->UpdateProfile($id);
      $this->RedirectToDomain();
    }

    function UpdateAccount(){
     global $session;
     $this->UpdateProfile($session['user_session']['id']);
    }

    function UpdateAccount_Action(){
     global $session;
     $this->UpdateProfile_Action($session['user_session']['id']);
     $this->RedirectToDomain();
    }

    function EnableStatus($id){
      $this->UserEnableStatus->EnableStatus($id);
      $this->RedirectToDomain();
    }

    function DisableStatus($id){
      $this->UserDisableStatus->DisableStatus($id);
      $this->RedirectToDomain();
    }




}