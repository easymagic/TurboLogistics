<?php
/**
@Inject(@models/DispatchRequest/filters/DispatchRequestFilterBooked,
        @models/DispatchRequest/filters/DispatchRequestFilterCardPayment,
        @models/DispatchRequest/filters/DispatchRequestFilterCashPayment,
        @models/DispatchRequest/filters/DispatchRequestFilterDropped,
        @models/DispatchRequest/filters/DispatchRequestFilterDroppedOff,
        @models/DispatchRequest/filters/DispatchRequestFilterPicked,
        @models/DispatchRequest/DispatchRequestBookRequest,
        @models/DispatchRequest/DispatchRequestConfirmPaymentAsCard,
        @models/DispatchRequest/DispatchRequestCancelRequest,
        @models/DispatchRequest/DispatchRequestConfirmPaymentAsCash,
        @models/DispatchRequest/DispatchRequestCreateRequest,
        @models/DispatchRequest/DispatchRequestDropOffRequest,
        @models/DispatchRequest/DispatchRequestDropRequest,
        @models/DispatchRequest/DispatchRequestGetRequestById,
        @models/DispatchRequest/DispatchRequestListRequests,
        @models/DispatchRequest/DispatchRequestPickupRequest,
        @models/DispatchRequest/metrics/DispatchRequestGetCount,
        @models/DispatchRequest/metrics/DispatchRequestGetSum);
*/

class DispatchRequestPlugin{
   
    function BookRequest($id,$dispatcher_id,$dispatcher_parent_id){
      $this->DispatchRequestBookRequest->BookRequest($id,$dispatcher_id,$dispatcher_parent_id);
    }

    function ConfirmPaymentAsCard($id,$user_id){
      $this->DispatchRequestConfirmPaymentAsCard->ConfirmPaymentAsCard($id,$user_id);
    }

    function CancelRequest($id){
      $this->DispatchRequestCancelRequest->CancelRequest($id);
    }

    function ConfirmPaymentAsCash($id,$user_id){
     $this->DispatchRequestConfirmPaymentAsCash->ConfirmPaymentAsCash($id,$user_id);
    }

    function CreateRequest($customer_id){
     $this->DispatchRequestCreateRequest->CreateRequest($customer_id);
    }

    function DropOffRequest($id){
     $this->DispatchRequestDropOffRequest->DropOffRequest($id);
    }

    function DropRequest($id){
     $this->DispatchRequestDropRequest->DropRequest($id); 
    }

    function GetRequestById($id){
     $this->DispatchRequestGetRequestById->GetRequestById($id);
    }

    function ListRequests(){
      $this->DispatchRequestListRequests->ListRequests();
    }

    function PickupRequest($id){
      $this->DispatchRequestPickupRequest->PickupRequest($id); 
    }

}