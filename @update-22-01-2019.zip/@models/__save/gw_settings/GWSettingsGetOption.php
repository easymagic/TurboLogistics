<?php 

/**

@Inject(@models/gw_settings/GWSettingsGetList);

*/

class GWSettingsGetOption{

  function GetOption($name){
     // global $db_where;
     global $data;

     // $db_where = " where (name = '$name') ";
     
     $this->EntityRead->SetWhere("name = '$name'"); 
     $this->GWSettingsGetList->GetList();

     if (count($data['gw_settings_data']) > 0){
        return $data['gw_settings_data'][0]['value'];
     }else{
     	return '';
     }

  }

}