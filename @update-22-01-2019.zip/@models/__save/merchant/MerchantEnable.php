<?php 
/**

@Inject(@models/entityv2/EntityEnableField);

*/

class MerchantEnable{

   

   function Enable($id){

   	  $this->EntityRead->SetWhere("id=$id");
   	  $this->EntityEnableField->EnableField('merchant','status');

   }




}