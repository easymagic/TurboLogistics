<?php 
/**
@Inject(@models/entityv2/EntityChangePasswordReset);
*/


class CustomerChangePasswordReset_Action{
  


    function ChangePasswordReset_Action($id,$check){
      $this->EntityChangePasswordReset->ChangePasswordReset('customer',$id,$check);
    }


}