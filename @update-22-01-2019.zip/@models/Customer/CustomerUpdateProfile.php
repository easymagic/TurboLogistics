<?php 
/**
@Inject(@models/entityv2/EntityUpdate);
*/

class CustomerUpdateProfile{

  

   function UpdateProfile($id){
   	 global $postData;

     $this->EntityRead->SetWhere("id=$id");
     $this->EntityUpdate->SetData($postData);
     $this->EntityUpdate->DoUpdate('customer');
   }


}