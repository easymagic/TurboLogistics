<?php 
/**
@Inject(@models/entityv2/EntityRead);
*/

class UserFilterDispatcher{

   
     function FilterDispatcher(){
     	$this->EntityRead->SetWhere("role='dispatcher'");
     }


}