<?php 
/**
@Inject(@models/entityv2/EntityAccountCreate,
        @models/User/UserUpdateCompanyLogo);
*/

class UserRegister_Action{

  


   function Register_Action(){
   	 global $post;
   	 global $postData;
   	 global $newID;

     global $parent_id;

     $postData['parent_id'] = $parent_id;
   	 
   	 $this->EntityCheckPassword->SetData($post);
   	 $this->EntityAccountCreate->SetData($postData);
   	 $this->EntityAccountCreate->SetDuplicateField('email');
     $this->EntityAccountCreate->AccountCreate('user');

     if ($postData['role'] == 'company' && !empty($newID)){
        $this->UserUpdateCompanyLogo->UpdateCompanyLogo($newID);
     }

   }


}