<?php 
/**
@Inject(@models/User/UserUpdateProfile_Action);
*/
class UserUpdateAccount_Action{

  

  function UpdateAccount_Action(){
  	global $session;
  	$id = $session['user_session']['id'];
    $this->UserUpdateProfile_Action->UpdateProfile_Action($id);
  }



}