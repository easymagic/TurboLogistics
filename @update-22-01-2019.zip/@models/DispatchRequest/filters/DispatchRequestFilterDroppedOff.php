<?php 
/**
@Inject(@models/entityv2/EntityRead);
*/

class DispatchRequestFilterDroppedOff{

   
    function FilterDroppedOff(){
    	$this->EntityRead->SetWhere("dispatch_status='droppedoff'");
    }

}