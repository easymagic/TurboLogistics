<?php 
/**
@Inject(@models/Customer/CustomerChangePasswordReset_Action);
*/
class AuthCustomerChangePasswordReset_Action{
  

   function ChangePasswordReset_Action($id,$check){
    $this->CustomerChangePasswordReset_Action->ChangePasswordReset_Action($id,$check);
   }


}