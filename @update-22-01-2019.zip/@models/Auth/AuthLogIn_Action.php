<?php 
/**
@Inject(@models/User/UserLogIn_Action);
*/
class AuthLogIn_Action{

  

    function LogIn_Action(){
      $this->UserLogIn_Action->LogIn_Action();
    }


}