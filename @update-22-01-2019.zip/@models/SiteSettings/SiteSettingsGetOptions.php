<?php
/**
@Inject(@models/SiteSettings/SiteSettingsGetOption);
*/
class SiteSettingsGetOptions{


  

   function GetOptions(){

   	 global $data;
     $data['charging_flat_rate'] = $this->SiteSettingsGetOption->GetOption('charging_flat_rate');
     $data['service_charge'] = $this->SiteSettingsGetOption->GetOption('service_charge');


   }



}