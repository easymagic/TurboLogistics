<?php 
/**

@Inject(@models/entityv2/EntityRead);

*/


class EntitySendPasswordReset{

  private $ctrl;

   function SendPasswordReset($entity,$ctrl){

   	 // global $db_where;
   	 global $data;
   	 global $emailQueue;
     global $from;
     global $post;

     $email = $post['email'];

     $this->ctrl = $ctrl;

   	 $data['error'] = false;

   	 // $db_where = " where (email = '" . $email . "')";

     $this->EntityRead->SetWhere("email = '" . $email . "'");

   	 $this->EntityRead->Read($entity);

   	 if (count($data[$entity . '_data']) > 0){
        $data[$entity . '_data'] = $data[$entity . '_data'][0];

        $name = 'User';
        $data_ = $data[$entity . '_data'];
        if (isset($data_['first_name'])){
          $name = $data_['first_name'];
        }else if (isset($data_['name'])){
          $name = $data_['name'];
        }

        $name = ucfirst($name);

        $message = 'Dear ' . $name . ',<br />
          Your Password-Reset request was successful,<br />
          Click ' . $this->GetResetLink($entity,'here',$data_['id']) . ' to reset your password.
          <br />
          <br />
          <br />
          Kind Regards
        ';
        $to = $data_['email'];
        $from = 'info@turboerrands.com';
        $subject = 'PASSWORD RESET.';

        $emailQueue[] = array(
          'to'=>$to,
          'subject'=>$subject,
          'message'=>$message,
          'from'=>$from
        );

        $data['message'] = 'A password reset link has been sent to your E-mail.';

   	 }else{
   	 	$data['error'] = true;
   	 	$data['message'] = 'This E-mail does not exist on this platform!';
   	 }
     
   }

   private function GetResetLink($entity,$link,$id){
     $check = 'check' . $id;
     $check = md5($check);
     $r = BASE_URL . $this->ctrl . '/ChangePasswordReset/' . $id . '/' . $check;
     
     return '<a href="' . $r . '">' . $link . '</a>';
   }




}