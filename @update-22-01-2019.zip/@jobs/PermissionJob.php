<?php 
$actionPermission = true;
$permission = true;
