<?php 
global $routeAction;
// global $adminToolBarMenu;
CallAction('Admin_HTML_Start');
CallAction('Admin_Header');

CallAction('Admin_LoginHeader');//for login

CallAction('Admin_SideBar'); //aside
CallAction('Admin_Content_PreStart');

CallAction('Init_AdminContent');
CallAction($routeAction . '_AdminContent');

CallAction('Admin_Content_PreStop');
CallAction('Admin_Footer');

CallAction('Admin_LoginFooter'); //for login

CallAction('Admin_HTML_Stop');

//Garbage sessions here
