<?php 
/**
@Inject(@plugins/apis/UserPlugin,
        @plugins/authlogged/AdminBackEndPlugin,
        @plugins/ai/BrainChildPlugin);
*/

class Dispatcher{
  

  function Init(){
  	global $me;
  	

  	$me = 'Dispatcher';
    
    InstallTheme('@themes/AdminBackEndFramework');

    InstallPlugin($this->UserPlugin);
    InstallPlugin($this->AdminBackEndPlugin);
    InstallPlugin($this->BrainChildPlugin);

    

  }

  function Page_Init(){
  	global $postData;
    $postData['role'] = 'dispatcher'; //set this by default from the server-side for security reasons.
  }

  function Before_GetList(){
  	global $db_where;
    global $parent_id;
  	$this->EntityRead->SetWhere("role='dispatcher'");
    $this->EntityRead->SetWhere("parent_id=$parent_id");
  }

  function GetList_AdminContent(){
  	global $db_query_log;
  	// print_r($db_query_log);
  }

  function UpdateProfile_AdminContent(){}
  function ChangePassword_AdminContent(){}
  function Register_AdminContent(){}
  function EnableStatus_AdminContent(){}
  function DisableStatus_AdminContent(){}




}