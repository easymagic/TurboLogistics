<?php
/**
@Inject(@plugins/apis/UserPlugin,
        @plugins/authlogged/AdminBackEndPlugin,
        @plugins/ai/BrainChildPlugin);
*/
class User{

  
  function Init(){

    
    InstallTheme('@themes/AdminBackEndFramework');

    InstallPlugin($this->UserPlugin);
    InstallPlugin($this->AdminBackEndPlugin);
    InstallPlugin($this->BrainChildPlugin);
    
  }

  function Index(){
  	echo 'index.. loaded.';
  }

  function ChangeAccountPassword_AdminContent(){}


}