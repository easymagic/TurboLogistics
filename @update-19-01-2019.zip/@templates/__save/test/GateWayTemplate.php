<!DOCTYPE html>
<html>
<head>
	<title>G-Way</title>
</head>
<body>
  <h1 align="center"><?php echo $gway; ?></h1>
</body>
</html>