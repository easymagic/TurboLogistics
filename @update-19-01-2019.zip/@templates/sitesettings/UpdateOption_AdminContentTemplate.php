<section class="content-header">
      <h1>
        Update Setting (<?php echo $name; ?>)
        <!-- <small>Version 2.0</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Update Setting (<?php echo $name; ?>)</li>
      </ol>
</section>


<section class="content">
<div class="row">


<div class="col-md-8">
          




<div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Update Setting (<?php echo $name; ?>)</h3>

              <a href="<?php echo BASE_URL; ?>SiteSettings/GetOption" class="btn btn-primary btn-sm pull-right">Back</a>

            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="post">
              <div class="box-body">

                <div class="form-group">
                  <label for="exampleInputEmail1"><?php echo $name; ?></label>
                  <input type="text" name="data[<?php echo $name; ?>]" class="form-control" id="exampleInputEmail1" placeholder="Enter <?php echo $name; ?>" value="<?php echo $$name; ?>">
                </div>


              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Save Setting</button>
              </div>
            </form>
          </div>

          

</div>

  <!-- /.col -->
</div>
</section>      