<?php 
class RequestThread{
    
    private $called = false;
    
    

	function Run(){
		// global $post;
		// global $request;

	 if (!$this->called){
       $this->called = true;
       $this->LoadVars(); 
	 }

	 // print_r($post);
	 // print_r($_POST);
	 // print_r($request);
	 // print_r($_REQUEST);

	}



	function LoadVars(){

		$GLOBALS['dataJSON'] = array();
		$GLOBALS['dependencyData'] = array();
		$GLOBALS['headers'] = array();
		$GLOBALS['requestBody'] = array();
		$GLOBALS['headers'] = array();
		$GLOBALS['headers'] = getallheaders();

		/////Decode Payload (As a side Effect)////////
		$requestBody = file_get_contents('php://input');
		$requestBodyData = array();

		if (!empty($requestBody) && is_array(json_decode($requestBody,true))){
		 $requestBodyData = json_decode($requestBody,true);	
		 foreach ($requestBodyData as $k=>$v){
		    $_REQUEST[$k] = $v;
		    $_POST[$k] = $v;
		 }
		}

		DefineGlobal('post',$_POST);
		DefineGlobal('files',$_FILES);

		// $GLOBALS['requestBody'] = $requestBody;
		$GLOBALS['requestData'] = $requestBodyData;
		DefineGlobal('requestBody',$requestBody);

		$GLOBALS['request'] = &$_REQUEST;
		$GLOBALS['response'] = array();


		$GLOBALS['postData'] = array();
		if (isset($GLOBALS['post']['data'])){
		 $GLOBALS['postData'] = &$GLOBALS['post']['data'];
		}

		$GLOBALS['requestData'] = array();
		if (isset($GLOBALS['request']['data'])){
		 $GLOBALS['requestData'] = &$GLOBALS['request']['data'];
		}

		$GLOBALS['get'] = &$_GET;
		$GLOBALS['session'] = &$_SESSION;

	}

  
  


}