<?php 
 
/**
@Inject(app-x/core/ObjectProxy);
*/ 



 class PluginLoader{

   private $plugins = array();
   private $pluginsObj = array();

   private $obj;
   private $method;
   private $name;
   private $args;
   private $plgs = array();

   function SetParams($plgs,$obj,$name,$method,$args){
     $this->plgs = $plgs;
     $this->obj = $obj;
     $this->name = $name;
     $this->args = $args;
   } 

   private function GetDirContents($dir){
     $hnd = scandir($dir);
     $hnd = array_diff($hnd, array('.','..'));
     return $hnd;
   }

   private function IsThemeDir($file){
    //_enabled
    return (is_dir($file) && substr($file, -8) == '_enabled');
   }
   
   function GetPlugins(){
    if (count($this->plugins) <= 0){

      $contents = $this->GetDirContents('@plugins');


      foreach ($contents as $k=>$v){

         if ($this->IsThemeDir('@plugins/' . $v)){


           $contents2 = $this->GetDirContents('@plugins/' . $v);

           foreach ($contents2 as $k2=>$v2){
              
             $name  = explode('.', $v2);
             array_pop($name);
             $name = array_pop($name);
             $pluginDir = '@plugins/' . $v . '/' . $name;
             $this->pluginsObj[$name] = InjectKey($pluginDir);  //DIContainer::GetInstance()->DecodeAnnotationKey($pluginDir);
             $this->plugins[$name] = $this->pluginsObj[$name];


           }

         }
      }
      //$this->plugins = array_diff($this->plugins, array('.','..'));
      // foreach ($this->plugins as $k=>$v){
      //    $name  = explode('.', $v);
      //    array_pop($name);
      //    $name = array_pop($name);
      //    $pluginDir = '@plugins/' . $name;
      //    $this->pluginsObj[$name] = DIContainer::GetInstance()->DecodeAnnotationKey($pluginDir);
      // }
    }

    return $this->plugins; 
   }
   
   

   //$this->obj = DIContainer::GetInstance()->DecodeAnnotationKey($controllerPath);

   function CallPluginHooks($plugins,$obj,$name,$method,$args){
     
     $r = '';

     $this->GetPlugins();

     // $plugins = $this->plgs;
     // $obj = $this->obj;
     // $name = $this->name;


     // $args[] = array('sender'=>$obj,'plugins'=>$plugins,'obj'=>$obj,'name'=>$name,'method'=>$method,'args'=>$args,'loader'=>$this->ObjectProxy);

     foreach ($this->pluginsObj as $k=>$v){
       if (method_exists($v, 'SetEntity')){

         if (method_exists($v, 'GetScope')){
           if ($v->GetScope() == 'private'){
            if (in_array($k, $plugins)){
              // echo get_class($v) . '<br />';
              // if (get_class($v) == 'CrudTemplatePlugin'){
              //   echo $method . '<br />';
              // }
              $this->ApplyPlugin($r,$name,$v,$method,$args);
            }
           }else if ($v->GetScope() == 'public'){
             $this->ApplyPlugin($r,$name,$v,$method,$args);
           }  
         }else{
            $this->ApplyPlugin($r,$name,$v,$method,$args);
         }

          // $v->SetEntity($name);
          // $t = $this->ObjectProxy->CallProxy($v,$method,$args);
          // if (is_array($t)){
          //   if (empty($r)){
          //     $r = array();
          //   }
          //   $r = array_merge($r,$t);
          // }else{
          //   if (!is_array($r)){
          //     $r.=$t;
          //   }
          // }
       }
     }
     return $r;

   }


 private function ApplyPlugin(&$r,$name,$v,$method,$args){
          $v->SetEntity($name);
          $t = $this->ObjectProxy->CallProxy($v,$method,$args);
          // print_r($t);
          // echo get_class($v) . ",$method <br />";
          // echo get_class($v) . '<br />';
          if (is_array($t)){
            if (empty($r)){
              $r = array();
            }
            $r = array_merge($r,$t);
          }else{
            if (!is_array($r)){
              $r.=$t;
            }
          }  
 }


 }
