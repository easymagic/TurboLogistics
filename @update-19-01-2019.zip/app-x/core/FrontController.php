<?php 

/**
@Inject(app-x/core/PluginLoader,
        app-x/core/Router,
        app-x/core/RequestResponse);
*/


class FrontController{
  

  private $obj = null;
  private $name = '';
  private $method = 'Index';
  private $args = array();
  private $plugins = array();
  private $request = array();
  private $parentLookOut = array('dba'=>'DbaV2');
  private $headers = array();




  function __construct(){}

  // private function CheckParentLookOut($name){
  //   if (in_array($name, array_keys($this->parentLookOut))){
  //     // array_unshift($this->args,$this->name);
  //     array_unshift($this->args,$this->method);
  //     $this->name  = $this->parentLookOut[$name];
  //     $this->method = 'Map'; //http://localhost/forde/Dba/category/[ShowList,Add,Edit]
  //     $controllerPath = '@controllers/' . $this->name;
  //     $this->obj = DIContainer::GetInstance()->DecodeAnnotationKey($controllerPath);

  //   }
  // }

  function GetDispatch($route,$headers_=array()){
    
    global $routeName;
    global $routeAction;
    global $routeArgs;    
    global $headers;
    global $routeObject;

    foreach ($headers_ as $k=>$v){
      $headers[$k] = $v;
    }

    // $this->headers = $headers;
    $this->request = $route; // $_REQUEST['__request__'];
    // $this->RequestResponse->SetRequest($_REQUEST);
    $r = explode('/', $this->request);

    if (count($r) >= 1){
     $routeName = array_shift($r);
     $routeAction = array_shift($r);
     $routeArgs = $r;
    }else{
     $routeName = DEFAULT_CONTROLLER;
    }

    if (empty($routeAction) || is_numeric($routeAction)){
     $routeAction = 'Index';
    }

    $controllerPath = '@controllers/' . $routeName;

    $routeName = strtolower($routeName);

    $obj = InjectKey($controllerPath); 
    
    $routeObject = $obj;

    // DIContainer::GetInstance()->DecodeAnnotationKey($controllerPath);

    // $plugins = $this->DecodePluginUse($obj);
    
    return $this->DispatchRequest_();

  }

  // function GetHeaders(){
  //   return $this->headers;
  // }

  function DispatchRequest(){
     return $this->GetDispatch($_REQUEST['__request__']);
  }

 
  function DispatchRequest_(){
   global $buffer;
   
   try {
     
     $this->Router->Dispatch();
     
   } catch (Exception $e) {
     
     $buffer = $e->getMessage();

   }

  }






}