<?php 
/**
@Inject(@models/entityv2/EntityRead);
*/


class CustomerGetList{


  function GetList(){
   $this->EntityRead->Read('customer');
  }


}