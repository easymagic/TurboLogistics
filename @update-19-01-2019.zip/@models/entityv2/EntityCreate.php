<?php 

class EntityCreate{
   
   private $data;


   function DoCreate($entity){
     global $newID;
     DbCreate($entity,$this->data);
     return $newID;
   }

   function SetData($data){
     $this->data = $data;
   }




}