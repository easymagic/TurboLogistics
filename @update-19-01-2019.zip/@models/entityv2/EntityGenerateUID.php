<?php 

/**

@Inject(@models/entityv2/EntityUpdate);

*/


class EntityGenerateUID{



   function GenerateUID($entity,$field,$id,$len=5){ //Standardization (email,password,status)
   	 
     global $UID;

     $this->EntityUpdate->EntityRead->SetWhere("id=$id");
     $this->EntityUpdate->SetData(array($field=>$this->GenUID($id,$len)));
     $this->EntityUpdate->DoUpdate($entity);      

   }

   private function GenUID($id,$len){
   	 global $UID;

     $r = md5($id);
     $r = substr($r, -1 * $len);
     $UID = $r;
     return $r;
   }




}