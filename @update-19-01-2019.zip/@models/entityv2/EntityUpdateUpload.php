<?php 
/**
@Inject(@models/entityv2/EntityRead);
*/
class EntityUpdateUpload{

   private $data = array();

   function UpdateUpload($entity,$field,$path){

   	 global $db_where;
   	 global $db_sql;

   	 $this->DoUpload($field,$path);
     
     if (!empty($db_where) && !empty($this->data)){
      DbUpdate($entity,$this->data);
     }

     // die($db_sql);
     
   }

   private function GetSalt($id){
     $r = md5(uniqid() . md5($id));
     $r = substr($r, -7);
     return $r;
   }

   private function DoUpload($name,$path){
     global $files;

     if (isset($files[$name])){
      
       $name_ = $this->GetSalt($files[$name]['name']) . '_' . $files[$name]['name'];

       if (move_uploaded_file($files[$name]['tmp_name'], $path . $name_)){
          $this->SetData(array($name=>$name_));
       }
     }
   }

   private function SetData($data){
    $this->data = $data;
   }



}