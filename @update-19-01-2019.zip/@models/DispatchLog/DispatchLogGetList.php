<?php 
/**
@Inject(@models/entityv2/EntityRead);
*/
class DispatchLogGetList{
 


  function GetList(){
    
    $this->EntityRead->Read('dispatch_log');

  }


}