<?php 
/**
@Inject(@models/entityv2/EntityRead);
*/

class DispatchRequestFilterDropped{

   
    function FilterDropped(){
    	$this->EntityRead->SetWhere("dispatch_status='dropped'");
    }

}