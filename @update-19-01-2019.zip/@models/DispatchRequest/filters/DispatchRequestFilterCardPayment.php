<?php 
/**
@Inject(@models/entityv2/EntityRead);
*/

class DispatchRequestFilterCardPayment{

   
    function FilterCardPayment(){
    	$this->EntityRead->SetWhere("payment_type='card'");
    }

}