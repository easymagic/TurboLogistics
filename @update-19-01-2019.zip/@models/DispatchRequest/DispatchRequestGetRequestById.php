<?php 
/**
@Inject(@models/entityv2/EntityReadOne);
*/
class DispatchRequestGetRequestById{

   

     function GetRequestById($id){
       $this->EntityRead->SetWhere("id=$id");
       $this->EntityReadOne->ReadOne('dispatch_request');
     }


}