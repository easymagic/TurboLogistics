<?php 
/**
@Inject(@models/entityv2/EntityCount);
*/
class DispatchRequestGetCount{


   function GetCount(){
   	return $this->EntityCount->GetCount('dispatch_request');
   }


}