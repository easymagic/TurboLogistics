<?php 
/**
@Inject(@models/entityv2/EntitySum);
*/
class DispatchRequestGetSum{


   
   function GetSum(){
   	return $this->EntitySum->GetSum('dispatch_request','dispatch_amount');
   }


}