<?php 
/**
@Inject(@models/entityv2/EntityRead);
*/
class DispatchRequestListRequests{

   

     function ListRequests(){
       // $this->EntityRead->SetWhere("id=$id");
       $this->EntityRead->Read('dispatch_request');
     }


}