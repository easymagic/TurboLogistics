<?php 
/**
@Inject(@models/entityv2/EntityUpdate,
        @models/entityv2/EntityReadOne,
        @models/User/UserGetProfile,
        @models/User/UserGetBusyStatus,
        @models/DispatchLog/DispatchLogRequest,
        @models/DispatchRequest/DispatchRequestGetRequestById);
*/
class DispatchRequestCancelRequest{

   

     function CancelRequest($id){
       global $data;
       
       // $this->GetDispatcherData($dispatcher_id);

       $this->DispatchRequestGetRequestById->GetRequestById($id);
       // $this->EntityRead->SetWhere("id=$id");
       // $this->EntityReadOne->ReadOne('dispatch_request');

       if (in_array($data['dispatch_request_data']['dispatch_status'],array('booked'))){ //,'cancelled'
          
         $this->UserGetBusyStatus->GetBusyStatus($data['dispatch_request_data']['user_id']); 

         $dispatcher_id = $data['dispatch_request_data']['user_id'];

         $this->EntityRead->SetWhere("id=$id");
         
         $this->EntityUpdate->SetData(array(
          'user_id'=>'',
          'user_parent_id'=>'',
          'dispatch_status'=>'cancelled'
         ));

         $this->EntityUpdate->DoUpdate('dispatch_request');
         $data['message'] = 'Request cancelled.';
         $data['error'] = false;

         // $data['dispatch_request_data']['user_id'] = $dispatcher_id;
         // $data['dispatch_request_data']['user_parent_id'] = $dispatcher_parent_id;

         ///update dispatcher to booked
         $this->EntityRead->SetWhere("id=$dispatcher_id");
         $this->EntityUpdate->SetData(array(
           'dispatch_availability'=>'free'
         ));
         $this->EntityUpdate->DoUpdate('user');

         ///send notification
         // $this->SendNotification($data['dispatch_request_data']);

         //Log this request.
         $this->DispatchLogRequest->LogRequest(array(
           'dispatch_id'=>$id,
           'dispatch_status'=>'cancelled',
           'user_id'=>$dispatcher_id,
           'lat'=>$data['user_data']['lat'],
           'lng'=>$data['user_data']['lng'],
           'address'=>$data['user_data']['current_address']
         ));

       }else{
         $data['message'] = 'This request has passed the stage of being cancelled!';
         $data['error'] = true;
       }


     }

     // private function GetDispatcherData($user_id){
     //   $this->UserGetProfile->GetProfile($user_id);
     // }


     private function SendNotification(){

     }


}