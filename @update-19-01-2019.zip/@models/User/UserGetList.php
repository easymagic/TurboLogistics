<?php 
/**
@Inject(@models/entityv2/EntityRead);
*/


class UserGetList{


  function GetList(){
   $this->EntityRead->Read('user');
  }


}