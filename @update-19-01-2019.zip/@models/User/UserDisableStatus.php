<?php 
/**
@Inject(@models/entityv2/EntityDisableField);
*/
class UserDisableStatus{
  

   function DisableStatus($id){
   	  global $data;
   	  $this->EntityRead->SetWhere("id=$id");
      $this->EntityDisableField->DisableField('user','status');
      $data['message'] = 'Account disabled.';
   }


}