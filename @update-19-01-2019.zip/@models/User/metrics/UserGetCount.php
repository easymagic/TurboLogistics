<?php 
/**
@Inject(@models/entityv2/EntityCount);
*/

class UserGetCount{

  
  function GetCount(){
  	return $this->EntityCount->GetCount('user');
  }


}