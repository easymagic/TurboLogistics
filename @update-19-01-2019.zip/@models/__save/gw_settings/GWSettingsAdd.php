<?php 

/**

@Inject(@models/entityv2/EntityCreate);

*/

class GWSettingsAdd{


  function Add(){
    global $postData;
    global $data;
    $this->EntityCreate->SetData($postData);
    $this->EntityCreate->DoCreate('gw_settings');
    $data['message'] = 'Option Added.';
  }

}