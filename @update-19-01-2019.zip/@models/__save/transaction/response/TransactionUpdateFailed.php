<?php 
/**

@Inject(@models/entityv2/EntityUpdate);

*/


class TransactionUpdateFailed{
  


  function UpdateFailed($criteria){
     $this->EntityUpdate->Update('transaction',array('pstatus'=>'failed'),$criteria);
  }



}