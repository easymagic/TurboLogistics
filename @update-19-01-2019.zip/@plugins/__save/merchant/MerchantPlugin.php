<?php 

/**

@Inject(@models/merchant/MerchantGetOne,
        @models/merchant/MerchantChangePassword,
        @models/merchant/MerchantUpdate);

*/



class MerchantPlugin{



  function ChangePassword_Action(){
   global $merchantID;
   $this->MerchantChangePassword->ChangePassword($merchantID);
  }

  function EditProfile_AdminContent(){
   global $merchantID;
   $this->MerchantGetOne->GetOne($merchantID);

  }

  function EditProfile_Action(){
    global $merchantID;
    $this->MerchantUpdate->Update($merchantID);
  }
 
  
  function Init_Merchant(){
    global $merchantID;
    global $db_where;

    $db_where = " where (id = $merchantID)";    
  }

  function Init_Transaction(){
    global $transactionFilters;
    global $merchantID;
    global $db_where;
    $transactionFilters[] = "merchant_id = '$merchantID'";
    // echo 'Called.';
    $db_where = " where (" . implode(' and ', $transactionFilters) . ") ";
  }


  function LogOut(){
    global $session;
    global $data;
    global $redirect;
    unset($session['merchant_session']);
    $data['message'] = 'Just logged out :)';
    $redirect = 'Accounts/MerchantLogin';
  }


 

}