<?php 

/**

@Inject(@services/Db);

*/

class UIPlugin{

  private $entity;


  function SetEntity($entity=''){
    $this->entity = $entity;
  }

  function DropDown($name='',$label='name',$value='id'){
    
    $record = $this->Db->Get($this->entity);
    $r[] = '<select name="' . $name . '">';
    $r[] = '<option value="">--Select--</option>';
       foreach ($record as $k=>$v){
        $r[] = '<option value="' . $v[$value] . '">' . $v[$label] . '</option>';
       }

    $r[] = '</select>';

    echo implode('', $r);

  }




}


