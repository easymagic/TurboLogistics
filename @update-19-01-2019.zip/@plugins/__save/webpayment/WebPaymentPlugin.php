<?php 

/**

@Inject(@models/transaction/TransactionGetList);

*/


class WebPaymentPlugin{

  
  function GateWay($uid=''){
   global $db_where;
   global $data;
   $db_where = " where (interpay_reference = '$uid')";
   $this->TransactionGetList->GetList(); 
   if (count($data['transaction_data']) > 0){
     $data['transaction_data'] = $data['transaction_data'][0];
   }
  }

  function Feedback(){

  }


}